"""
retraction_screener/rw_matcher.py
Retraction Watch database matcher.

Loads retracted article data and provides matching by DOI or PMID.
"""

import csv, os, json

class RetractionWatchMatcher:
    """Matches references against the Retraction Watch database."""

    def __init__(self, data_dir='data'):
        self.data_dir = data_dir
        self._db = None

    def load_rw_database(self):
        """
        Load the retracted articles database from our processed data.

        Returns
        -------
        dict
            DOI → {pmid, doi, title, journal, year, cited_by_count}
        """
        if self._db is not None:
            return self._db

        db = {}
        csv_path = os.path.join(self.data_dir, 'processed', 'retraction_citation_check.csv')
        if not os.path.exists(csv_path):
            print(f'WARNING: RW database not found at {csv_path}')
            self._db = db
            return db

        with open(csv_path, encoding='utf-8') as f:
            for row in csv.DictReader(f):
                doi = row.get('doi', '').strip().lower()
                if doi:
                    db[doi] = {
                        'doi': doi,
                        'pmid': row.get('pmid', ''),
                        'title': row.get('title', ''),
                        'journal': row.get('journal', ''),
                        'year': row.get('year', ''),
                        'cited_by_count': row.get('cited_by_count', '0'),
                        'reason': 'Retracted publication',
                        'date': row.get('year', ''),
                    }

        self._db = db
        print(f'RetractionWatch DB loaded: {len(db)} entries')
        return db

    def match_ref(self, ref):
        """
        Match a single reference against the database.

        Parameters
        ----------
        ref : dict
            Reference with optional 'doi' and/or 'pmid' keys

        Returns
        -------
        dict or None
            Match record if found, None otherwise
        """
        db = self.load_rw_database()

        doi = (ref.get('doi') or '').strip().lower()
        pmid = (ref.get('pmid') or '').strip()

        if doi and doi in db:
            return db[doi]

        if pmid:
            for entry in db.values():
                if entry.get('pmid') == pmid:
                    return entry

        return None
