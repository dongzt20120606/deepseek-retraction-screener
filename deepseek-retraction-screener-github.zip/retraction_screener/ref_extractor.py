"""
retraction_screener/ref_extractor.py
Reference extraction from PDF and text input.

Currently supports:
- pdfplumber-based extraction (local PDF files)
- Text-based structured input (for testing/demo)
- Synthetic reference generator (for pipeline development)

In production, Grobid service is recommended for higher accuracy.
"""

import re, os

class ReferenceExtractor:
    """Extract references from PDF or structured text."""

    def extract_from_pdf(self, pdf_path):
        """
        Extract text and references from a PDF using pdfplumber.

        Parameters
        ----------
        pdf_path : str
            Path to PDF file

        Returns
        -------
        dict
            {'full_text': str, 'references_raw': [str]}
        """
        try:
            import pdfplumber
        except ImportError:
            raise ImportError("pdfplumber required for PDF extraction. Install: pip install pdfplumber")

        with pdfplumber.open(pdf_path) as pdf:
            full_text = []
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    full_text.append(text)

        full_text = '\n'.join(full_text)

        # Try to isolate the references section
        refs = self._isolate_references(full_text)

        return {
            'full_text': full_text,
            'references_raw': refs,
            'n_pages': len(pdf.pages),
        }

    def _isolate_references(self, full_text):
        """
        Heuristically isolate the reference section from full text.

        Looks for 'References', 'Bibliography', or numbered reference list patterns.
        """
        refs = []

        # Common section headers
        patterns = [
            r'(?:REFERENCES|BIBLIOGRAPHY|REFERENCE LIST)\s*\n([\s\S]*)',
            r'(?:References|Bibliography)\s*\n([\s\S]*)',
        ]

        ref_section = ''
        for p in patterns:
            m = re.search(p, full_text, re.IGNORECASE)
            if m:
                ref_section = m.group(1)
                break

        if not ref_section:
            return []

        # Split into individual references (numbered or bulleted)
        lines = ref_section.split('\n')
        current_ref = ''
        for line in lines:
            line = line.strip()
            if not line:
                continue
            # Check if this line starts a new reference (numbered or author-start)
            if re.match(r'^\d+[\.\)]\s', line):
                if current_ref:
                    refs.append(current_ref.strip())
                current_ref = line
            else:
                current_ref += ' ' + line

        if current_ref:
            refs.append(current_ref.strip())

        return refs

    def create_synthetic_references(self, include_retracted=True):
        """
        Create synthetic references for testing the pipeline.

        Returns
        -------
        list of dict
            References with keys: title, authors, journal, year, doi, pmid
        """
        refs = [
            {
                'title': 'Atezolizumab plus bevacizumab in unresectable hepatocellular carcinoma',
                'authors': 'Finn RS, Qin S, Ikeda M',
                'journal': 'N Engl J Med',
                'year': '2020',
                'doi': '10.1056/NEJMoa1915745',
                'pmid': '32402160',
                'raw_text': '',
            },
            {
                'title': 'Carnosic acid nanocluster-based framework combined with PD-1 inhibitors impeded tumorigenesis and enhanced immunotherapy in hepatocellular carcinoma',
                'authors': 'Wu W, Li Y, Wu X',
                'journal': 'Funct Integr Genomics',
                'year': '2023',
                'doi': '10.1007/s10142-023-01058-2',
                'pmid': '38182693',
                'raw_text': '',
            },
            {
                'title': 'Linc00210 drives Wnt/beta-catenin signaling activation and liver tumor cell self-renewal',
                'authors': 'Fu X, Zhu Y, Zheng B',
                'journal': 'Mol Cancer',
                'year': '2018',
                'doi': '10.1186/s12943-018-0909-x',
                'pmid': '29540185',
                'raw_text': '',
            },
            {
                'title': 'The PRISMA 2020 statement: an updated guideline for reporting systematic reviews',
                'authors': 'Page MJ, McKenzie JE, Bossuyt PM',
                'journal': 'BMJ',
                'year': '2021',
                'doi': '10.1136/bmj.n71',
                'pmid': '33782057',
                'raw_text': '',
            },
            {
                'title': 'Global cancer statistics 2020: GLOBOCAN estimates of incidence and mortality worldwide',
                'authors': 'Sung H, Ferlay J, Siegel RL',
                'journal': 'CA Cancer J Clin',
                'year': '2021',
                'doi': '10.3322/caac.21660',
                'pmid': '33538338',
                'raw_text': '',
            },
            {
                'title': 'Immunomodulatory Effect of Lycium barbarum Polysaccharides against Liver Fibrosis Based on the Intelligent Medical Internet of Things',
                'authors': 'Han Y, Zhou Y, Shan T',
                'journal': 'J Healthc Eng',
                'year': '2022',
                'doi': '10.1155/2022/3016556',
                'pmid': '35126934',
                'raw_text': '',
            },
            {
                'title': 'Effectiveness and safety of toripalimab, camrelizumab, and sintilimab in advanced hepatocellular carcinoma',
                'authors': 'Zhang Y, Li Z, Chen M',
                'journal': 'Ann Transl Med',
                'year': '2020',
                'doi': '10.21037/atm-20-4980',
                'pmid': '33241036',
                'raw_text': '',
            },
            {
                'title': 'Comparison of steroid-free immunosuppression and standard immunosuppression for liver transplant recipients',
                'authors': 'Xu X, Ling Q, He Z',
                'journal': 'PLoS One',
                'year': '2013',
                'doi': '10.1371/journal.pone.0071569',
                'pmid': '23940730',
                'raw_text': '',
            },
        ]

        if not include_retracted:
            refs = [r for r in refs if r.get('pmid') not in ('38182693', '29540185', '35126934', '33241036', '23940730')]

        return refs
