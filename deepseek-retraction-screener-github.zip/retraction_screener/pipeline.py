"""
retraction_screener/pipeline.py
Main pipeline orchestrator — coordinates the 6-step retraction screening process.

Pipeline steps:
  Step 1: Reference extraction (pdfplumber or grobid)
  Step 2: DOI/PMID resolution (CrossRef API)
  Step 3: Retraction Watch pre-filter
  Step 4: DeepSeek semantic classification (core)
  Step 5: Confidence calibration
  Step 6: Report generation
"""

import csv, json, os, time
from collections import OrderedDict
from .rw_matcher import RetractionWatchMatcher
from .deepseek_classifier import DeepSeekClassifier
from .report_generator import ReportGenerator

class RetractionScreener:
    """Main pipeline orchestrator."""

    def __init__(self, data_dir='data'):
        self.data_dir = data_dir
        self.rw_matcher = RetractionWatchMatcher(data_dir)
        self.classifier = DeepSeekClassifier()
        self.reporter = ReportGenerator()

    def run_pipeline(self, references, output_path=None):
        """
        Run the full 6-step pipeline on a list of references.

        Parameters
        ----------
        references : list of dict
            Each dict with keys: 'raw_text', optionally 'doi', 'pmid', 'title', 'authors', 'journal', 'year'
        output_path : str, optional
            Path to save the structured report CSV

        Returns
        -------
        list of dict
            Each reference with added fields:
            - 'status': CLEAN / RETRACTED / UNCERTAIN
            - 'confidence': float 0-1
            - 'match_source': 'rw_db' / 'deepseek' / 'manual'
            - 'match_detail': str
        """
        results = []
        rw_db = self.rw_matcher.load_rw_database()

        for i, ref in enumerate(references):
            result = ref.copy()

            # ── Step 1: Pre-extract (if PDF text input received) ──
            # (Already extracted by caller)

            # ── Step 2: DOI/PMID resolution ──
            # (Already resolved by caller if available)

            # ── Step 3: Retraction Watch pre-filter ──
            doi = ref.get('doi', '') or ''
            pmid = ref.get('pmid', '') or ''
            rw_hit = None

            if doi and doi in rw_db:
                rw_hit = rw_db[doi]
            elif pmid and pmid in {v.get('pmid','') for v in rw_db.values()}:
                rw_hit = next((v for k,v in rw_db.items() if v.get('pmid') == pmid), None)

            if rw_hit:
                result['status'] = 'RETRACTED'
                result['confidence'] = 0.98
                result['match_source'] = 'rw_db'
                result['match_detail'] = f"RetractionWatch: {rw_hit.get('reason','')} ({rw_hit.get('date','')})"
                results.append(result)
                continue

            # ── Step 4: DeepSeek semantic classification ──
            ds_result = self.classifier.classify(ref)

            result['status'] = ds_result['status']
            result['confidence'] = ds_result['confidence']
            result['match_source'] = 'deepseek'
            result['match_detail'] = ds_result.get('rationale', '')

            # ── Step 5: Confidence calibration ──
            if result['confidence'] < 0.5:
                result['status'] = 'UNCERTAIN'

            results.append(result)

        # ── Step 6: Report generation ──
        if output_path:
            self.reporter.save_csv(results, output_path)

        return results

    def print_summary(self, results):
        """Print a human-readable summary of findings."""
        total = len(results)
        retracted = [r for r in results if r.get('status') == 'RETRACTED']
        uncertain = [r for r in results if r.get('status') == 'UNCERTAIN']
        clean = [r for r in results if r.get('status') == 'CLEAN']

        print(f'=== Retraction Screening Summary ===')
        print(f'  Total references checked: {total}')
        print(f'  ✅ CLEAN:      {len(clean)} ({len(clean)*100//total}%)')
        print(f'  ⚠️  RETRACTED:  {len(retracted)} ({len(retracted)*100//total}%)')
        print(f'  ❓ UNCERTAIN:  {len(uncertain)} ({len(uncertain)*100//total}%)')
        if retracted:
            print()
            print('Retracted references:')
            for r in retracted:
                print(f'  ⚠️  [{r.get("match_source","?")}] {r.get("title","No title")[:60]}')
                print(f'      → {r.get("match_detail","")[:80]}')
