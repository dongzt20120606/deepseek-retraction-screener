"""
retraction_screener/deepseek_classifier.py
DeepSeek-powered semantic classification of reference retraction status.

Implements 4 prompt engineering strategies:
  v1: Zero-shot classification
  v2: Few-shot (with examples)
  v3: Chain-of-thought reasoning
  v4: Multi-turn (journal credibility → retraction likelihood)

In production, this uses the DeepSeek API.
In development/testing mode, it runs a rule-based fallback.
"""

import json, os, re
import urllib.request

# ── Prompt Templates ──

PROMPT_V1_ZERO_SHOT = """You are a research integrity assistant. Determine whether the following academic reference has been retracted.

Reference: {reference_text}

Output exactly one of these labels:
- CLEAN (no evidence of retraction)
- RETRACTED (confirmed as retracted)
- UNCERTAIN (cannot determine)

Label:"""

PROMPT_V2_FEW_SHOT = """You are a research integrity assistant. Determine whether an academic reference has been retracted.

Examples:

Reference: "Wu W, Li Y, Wu X, et al. Carnosic acid nanocluster-based framework combined with PD-1 inhibitors impeded tumorigenesis and enhanced immunotherapy in hepatocellular carcinoma. Funct Integr Genomics. 2023."
Label: RETRACTED

Reference: "Finn RS, Qin S, Ikeda M, et al. Atezolizumab plus bevacizumab in unresectable hepatocellular carcinoma. N Engl J Med. 2020;382:1894-1905."
Label: CLEAN

Reference: "Page MJ, McKenzie JE, Bossuyt PM, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ. 2021;372:n71."
Label: CLEAN

Now classify this reference:
Reference: {reference_text}
Label:"""

PROMPT_V3_CHAIN_OF_THOUGHT = """You are a research integrity assistant. Determine whether the following academic reference has been retracted. Think step by step.

Reference: {reference_text}

Step 1: Identify the journal and its general credibility (impact factor, known retraction track record).
Step 2: Check for known patterns associated with retracted papers (e.g., unusual methodology, bioinformatics-only studies in low-tier journals in 2022-2024).
Step 3: Determine if this paper belongs to a journal or time period with a high retraction rate.
Step 4: Make a final determination.

Output exactly one:
- CLEAN
- RETRACTED
- UNCERTAIN

Provide your reasoning in 1-2 sentences, then the label on a new line.

Reasoning: [your reasoning]
Label:"""

PROMPT_V4_MULTI_TURN = """You are a research integrity assistant. We will determine the retraction status of a reference in two rounds.

ROUND 1: Journal Credibility Assessment
Journal: {journal_text}
Year: {year}
Question: Is this journal known for having a significant number of retractions? Consider: the journal's impact factor, publisher (e.g., Hindawi, MDPI, Frontiers), and known retraction clusters.
Answer: [assess journal credibility as HIGH / MEDIUM / LOW]

ROUND 2: Article Assessment
Reference: {reference_text}
Given the journal credibility assessment above and the article details, determine if this specific article has been retracted.
Consider: Is this in a journal known for paper mills? Does the article type (bioinformatics, meta-analysis) match common retraction patterns? Is the year within a known problem period?
Output exactly one:
- CLEAN
- RETRACTED
- UNCERTAIN

Label:"""


class DeepSeekClassifier:
    """DeepSeek-based classifier for retraction status."""

    def __init__(self, prompt_version='v3', api_key=None, use_api=False):
        """
        Parameters
        ----------
        prompt_version : str
            One of 'v1', 'v2', 'v3', 'v4'
        api_key : str, optional
            DeepSeek API key (for production use)
        use_api : bool
            If False, use rule-based fallback (for testing)
        """
        self.prompt_version = prompt_version
        self.api_key = api_key or os.environ.get('DEEPSEEK_API_KEY', '')
        self.use_api = use_api

        self.prompts = {
            'v1': PROMPT_V1_ZERO_SHOT,
            'v2': PROMPT_V2_FEW_SHOT,
            'v3': PROMPT_V3_CHAIN_OF_THOUGHT,
            'v4': PROMPT_V4_MULTI_TURN,
        }

    def classify(self, ref):
        """
        Classify a reference's retraction status.

        Parameters
        ----------
        ref : dict
            Reference with keys: 'title', 'authors', 'journal', 'year', 'raw_text' (optional)

        Returns
        -------
        dict
            {'status': str, 'confidence': float, 'rationale': str}
        """
        if self.use_api:
            return self._classify_via_api(ref)
        else:
            return self._classify_via_rules(ref)

    def _build_prompt(self, ref):
        """Build the prompt text from the reference."""
        template = self.prompts.get(self.prompt_version, self.prompts['v3'])

        # Build reference text
        authors = ref.get('authors', '')
        title = ref.get('title', '')
        journal = ref.get('journal', '')
        year = ref.get('year', '')
        raw = ref.get('raw_text', '')

        if raw:
            reference_text = raw[:300]
        else:
            ref_parts = [p for p in [authors, title, journal, year] if p]
            reference_text = '. '.join(ref_parts)
            if not reference_text.endswith('.'):
                reference_text += '.'

        return template.format(
            reference_text=reference_text,
            journal_text=journal,
            year=year
        )

    def _classify_via_rules(self, ref):
        """
        Rule-based fallback classification for development/testing.

        Rules:
        - If DOI/PMID is in RW database → RETRACTED (handled by pipeline Step 3)
        - If journal is in known high-risk list → UNCERTAIN with lower confidence
        - If journal is generally reputable → CLEAN
        - Otherwise → UNCERTAIN
        """
        journal = (ref.get('journal') or '').lower()
        title = (ref.get('title') or '').lower()
        year = ref.get('year', '')

        # Known high-retraction-risk journals (from our CrossRef data)
        HIGH_RISK_JOURNALS = [
            'int wound j', 'international wound journal',
            'tumour biol', 'tumor biology',
            'comput math methods med', 'computational and mathematical methods in medicine',
            'j healthc eng', 'journal of healthcare engineering',
            'biomed res int', 'biomed research international',
            'contrast media mol imaging',
            'dis mark', 'disease markers',
            'comput intell neurosci', 'computational intelligence and neuroscience',
        ]

        # Known reputable journals (unlikely to have mass retractions)
        LOW_RISK_JOURNALS = [
            'bmj', 'lancet', 'jama', 'nejm', 'nature', 'science',
            'ann surg', 'ann intern med', 'cochrane',
            'journal of hepatology', 'hepatology',
            'gastroenterology', 'gut',
            'clin cancer res', 'cancer res', 'cancer cell',
        ]

        # Check high-risk patterns
        for hrj in HIGH_RISK_JOURNALS:
            if hrj in journal:
                # Check year: 2022-2024 were peak retraction years
                if year in ('2022', '2023', '2024'):
                    return {
                        'status': 'UNCERTAIN',
                        'confidence': 0.35,
                        'rationale': f'Published in {journal} ({year}), a high-retraction-risk journal. Recommend RW database lookup.'
                    }
                return {
                    'status': 'UNCERTAIN',
                    'confidence': 0.55,
                    'rationale': f'Published in {journal}, a known high-retraction journal.'
                }

        # Check low-risk patterns
        for lrj in LOW_RISK_JOURNALS:
            if lrj in journal:
                return {
                    'status': 'CLEAN',
                    'confidence': 0.90,
                    'rationale': f'Published in {journal}, a well-established peer-reviewed journal.'
                }

        # Default: uncertain
        return {
            'status': 'UNCERTAIN',
            'confidence': 0.70,
            'rationale': f'Journal {journal} not in known risk database. DeepSeek API verification recommended.'
        }

    def _classify_via_api(self, ref):
        """
        Production classification via DeepSeek API.

        Uses the DeepSeek Chat API (https://api.deepseek.com/v1/chat/completions).
        Compatible with OpenAI SDK.
        """
        import openai

        api_key = self.api_key or os.environ.get('DEEPSEEK_API_KEY', '')
        if not api_key:
            raise ValueError('DEEPSEEK_API_KEY not set. Set environment variable or pass api_key.')

        client = openai.OpenAI(
            api_key=api_key,
            base_url='https://api.deepseek.com/v1'
        )

        prompt = self._build_prompt(ref)

        # System message varies by prompt version
        if self.prompt_version == 'v4':
            # v4 multi-turn: send journal and article separately
            messages = [
                {"role": "system", "content": "You are a research integrity assistant. Your task is to detect retracted academic references."},
                {"role": "user", "content": f"ROUND 1 - Journal Credibility\nJournal: {ref.get('journal','')}\nYear: {ref.get('year','')}\nIs this journal known for retractions? Answer HIGH/MEDIUM/LOW risk."},
            ]
            # We'll do a 2-turn approach - first get journal assessment
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                temperature=0.3,
                max_tokens=150
            )
            round1 = response.choices[0].message.content.strip()
            
            # Round 2: full article assessment
            messages.append({"role": "assistant", "content": round1})
            messages.append({"role": "user", "content": f"ROUND 2 - Article Assessment\nReference: {prompt}\nGiven the journal assessment, determine retraction status. Output: CLEAN / RETRACTED / UNCERTAIN"})
            
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                temperature=0.3,
                max_tokens=100
            )
            full_response = round1 + '\n' + response.choices[0].message.content.strip()
        else:
            # v1/v2/v3: single-turn
            messages = [
                {"role": "system", "content": "You are a research integrity assistant specializing in detecting retracted academic publications."},
                {"role": "user", "content": prompt}
            ]
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                temperature=0.3,
                max_tokens=300 if self.prompt_version == 'v3' else 100
            )
            full_response = response.choices[0].message.content.strip()

        # Parse the response
        result = self._parse_api_response(full_response, ref)
        result['rationale'] = f'[DeepSeek {self.prompt_version.upper()}] ' + result.get('rationale', full_response[:200])
        return result

    def _parse_api_response(self, response_text, ref):
        """Parse DeepSeek API response to extract status and confidence."""
        upper = response_text.upper()

        # Extract label
        if 'RETRACTED' in upper or 'retracted' in response_text:
            # Check if it's explicitly saying NOT retracted
            if 'NOT RETRACTED' in upper or 'not retracted' in response_text.lower():
                status = 'CLEAN'
                confidence = 0.85
            else:
                status = 'RETRACTED'
                confidence = 0.88
        elif 'CLEAN' in upper:
            status = 'CLEAN'
            confidence = 0.85
        elif 'UNCERTAIN' in upper:
            status = 'UNCERTAIN'
            confidence = 0.50
        else:
            # Try to infer from response
            if any(word in response_text.lower() for word in ['retracted', 'withdrawn', '撤回']):
                status = 'RETRACTED'
                confidence = 0.80
            elif any(word in response_text.lower() for word in ['clean', 'valid', 'reliable', 'not retracted']):
                status = 'CLEAN'
                confidence = 0.80
            else:
                status = 'UNCERTAIN'
                confidence = 0.50

        return {
            'status': status,
            'confidence': confidence,
            'rationale': response_text[:300]
        }
