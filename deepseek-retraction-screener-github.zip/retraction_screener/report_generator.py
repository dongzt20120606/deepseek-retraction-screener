"""
retraction_screener/report_generator.py
Generates structured screening reports in CSV and JSON formats.
"""

import csv, json, os
from datetime import datetime

class ReportGenerator:
    """Generates screening reports."""

    def save_csv(self, results, output_path):
        """Save results as CSV."""
        fields = ['index', 'title', 'authors', 'journal', 'year', 'doi', 'pmid',
                  'status', 'confidence', 'match_source', 'match_detail']

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for i, r in enumerate(results):
                row = {
                    'index': i + 1,
                    'title': (r.get('title') or '')[:100],
                    'authors': (r.get('authors') or '')[:60],
                    'journal': (r.get('journal') or '')[:60],
                    'year': r.get('year', ''),
                    'doi': r.get('doi', ''),
                    'pmid': r.get('pmid', ''),
                    'status': r.get('status', 'UNCERTAIN'),
                    'confidence': r.get('confidence', 0),
                    'match_source': r.get('match_source', ''),
                    'match_detail': (r.get('match_detail') or '')[:200],
                }
                writer.writerow(row)

        n_retracted = sum(1 for r in results if r.get('status') == 'RETRACTED')
        n_uncertain = sum(1 for r in results if r.get('status') == 'UNCERTAIN')
        print(f'Report saved: {output_path}')
        print(f'  {len(results)} references | {n_retracted} retracted | {n_uncertain} uncertain')

    def save_json(self, results, output_path):
        """Save results as JSON with metadata."""
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_references': len(results),
            'summary': {
                'clean': sum(1 for r in results if r.get('status') == 'CLEAN'),
                'retracted': sum(1 for r in results if r.get('status') == 'RETRACTED'),
                'uncertain': sum(1 for r in results if r.get('status') == 'UNCERTAIN'),
            },
            'references': results,
        }
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f'JSON report saved: {output_path}')

    def generate_summary_table(self, results):
        """Generate a summary table for inclusion in papers."""
        n_total = len(results)
        n_retracted = sum(1 for r in results if r.get('status') == 'RETRACTED')
        n_clean = sum(1 for r in results if r.get('status') == 'CLEAN')
        n_uncertain = sum(1 for r in results if r.get('status') == 'UNCERTAIN')

        table = f'''
| Category | Count | Percentage |
|----------|------:|-----------:|
| Total references screened | {n_total} | 100% |
| ✅ Clean | {n_clean} | {n_clean*100//n_total if n_total else 0}% |
| ⚠️ Retracted (RW DB match) | {n_retracted} | {n_retracted*100//n_total if n_total else 0}% |
| ❓ Uncertain (requires review) | {n_uncertain} | {n_uncertain*100//n_total if n_total else 0}% |
'''
        # Add retracted references list
        if n_retracted:
            retracted = [r for r in results if r.get('status') == 'RETRACTED']
            table += '\n**Retracted References Found:**\n\n'
            table += '| # | Reference | Confidence |\n'
            table += '|---|-----------|-----------:|\n'
            for i, r in enumerate(retracted, 1):
                title = (r.get('title') or 'No title')[:50]
                table += f'| {i} | {title}... | {r.get("confidence", 0):.2f} |\n'

        return table
