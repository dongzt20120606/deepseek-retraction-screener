# OSF Registration — DeepSeek Retraction Screener

## Study Information

**Title**: DeepSeek large language model for automated detection of retracted references in systematic reviews: a diagnostic validation study

**Authors**: Hui Liu (ORCID: [add your ORCID])

**Description**: This study evaluates a DeepSeek LLM-powered pipeline for automatically detecting retracted references in systematic reviews. The pipeline combines a deterministic Retraction Watch database pre-filter with a DeepSeek semantic classifier using four prompt engineering strategies (zero-shot, few-shot, chain-of-thought, multi-turn dialogue). Diagnostic validation was performed against a 500-reference gold standard constructed through multi-layer annotation (database matching + journal risk screening + DeepSeek API classification + manual PubMed verification).

**Hypotheses**:
1. A combined database + LLM pipeline will detect retracted references with higher sensitivity than database-only approaches
2. Chain-of-thought prompting will outperform zero-shot, few-shot, and multi-turn dialogue for detecting retracted articles from high-risk journals
3. The pipeline will maintain 100% specificity (zero false positives)

## Design Plan

**Study type**: Retrospective diagnostic validation study

**Data source**: PubMed (E-utilities API), CrossRef REST API, Retraction Watch database

**Index test**: DeepSeek API (model: deepseek-chat, temperature: 0.3) with four prompt variants

**Reference standard**: Multi-layer annotation:
- Layer 1: Retraction Watch database matching + journal risk rules
- Layer 2: DeepSeek v3 (chain-of-thought) API classification
- Layer 3: Manual PubMed verification by domain expert

**Primary outcome**: Sensitivity at 100% specificity (pre-specified)

**Secondary outcomes**: F1 score, positive predictive value, negative predictive value, Cohen's κ for test-retest reproducibility

## Sampling Plan

**Existing data**: 55,361 systematic reviews/meta-analyses identified from PubMed; 9,999 PMIDs downloaded; 44 reviews with accessible reference lists; 2,308 extracted references; 100 positive controls injected; 500 references randomly sampled for annotation

## Variables

**Index test result**: RETRACTED / CLEAN / UNCERTAIN (confidence ≥ 0.50 threshold)

**Reference standard result**: RETRACTED / CLEAN (no indeterminate cases)

## Analysis Plan

**Statistical model**: Diagnostic 2×2 contingency table; Wilson 95% confidence intervals for sensitivity and specificity

**Primary analysis**: Full pipeline (RW DB + journal risk + DeepSeek v3 CoT) vs gold standard

**Subgroup analysis**: Comparison across 4 prompt versions (v1–v4)

**Missing data**: N/A — complete data on all 500 samples

## Registration

**Date**: [Add date]

**OSF Registration DOI**: [To be assigned]

**How to register**:
1. Go to https://osf.io/register
2. Log in with or create an OSF account
3. Click "Create new registration"
4. Select "OSF Preregistration" template
5. Fill in the information above
6. Upload this file as supporting documentation
7. Complete registration

---

*This registration is retrospective. The study was initiated as a methodology development project before the decision to pursue formal diagnostic validation.*
