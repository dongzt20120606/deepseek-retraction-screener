# DeepSeek Retraction Screener

> Automated detection of retracted references in systematic reviews using the DeepSeek large language model.

[![Python 3.14](https://img.shields.io/badge/python-3.14-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![DOI](https://img.shields.io/badge/DOI-10.1136%2Fbmj.r809-blue)](https://doi.org/10.1136/bmj.r809)

## Why This Exists

Retracted publications continue to be cited in systematic reviews, distorting meta-analytic conclusions and contaminating clinical practice guidelines. Manual screening of reference lists is time-prohibitive. This pipeline combines deterministic database matching with LLM-based classification to automate retraction screening.

In diagnostic validation against 500 gold-standard references, the full pipeline achieved **89.4% sensitivity**, **100% specificity**, and an **F1 score of 94.4%**.

## Quick Start

```bash
# Install dependencies
pip install openai pdfplumber scikit-learn

# Set your DeepSeek API key
export DEEPSEEK_API_KEY="sk-your-key-here"

# Run the pipeline
python run_screener.py --refs references.csv --prompt v3
```

## Pipeline Architecture

```
PDF/CSV Input
    │
    ▼
Step 1: Reference Extraction  (pdfplumber or structured input)
    │
    ▼
Step 2: DOI/PMID Resolution   (CrossRef API + NCBI E-utilities)
    │
    ▼
Step 3: RW DB Pre-filter      (404 retracted articles database)
    │                    │
    │  Matched?          │  Unmatched
    │  → RETRACTED       │
    │                    ▼
    │              Step 4: DeepSeek Classifier  (v1-v4 prompt variants)
    │                    │
    │                    ▼
    │              Step 5: Confidence Calibration  (<0.50 → UNCERTAIN)
    │                    │
    │                    ▼
    │              Step 6: Report Generation  (CSV + JSON)
    │
    ▼
Structured Report
```

## Installation

**Prerequisites**: Python 3.14+, DeepSeek API key

```bash
git clone https://github.com/YOUR_USERNAME/deepseek-retraction-screener
cd deepseek-retraction-screener
pip install openai pdfplumber scikit-learn matplotlib seaborn
```

## Usage

### Basic Pipeline

```python
from retraction_screener.pipeline import RetractionScreener

screener = RetractionScreener()
results = screener.run_pipeline(
    references=[...],  # list of dicts with title, authors, journal, year, doi
    output_path="output/"
)
```

### Command Line

```bash
# Screen a single PDF
python run_screener.py --pdf paper.pdf --prompt v3

# Batch process from CSV
python run_screener.py --refs references.csv --prompt v3 --output results/

# Use Retraction Watch pre-filter only (no API cost)
python run_screener.py --refs references.csv --db-only
```

### Prompt Versions

| Version | Method | Description |
|---------|--------|-------------|
| v1 | Zero-shot | Direct query: "Is this reference retracted?" |
| v2 | Few-shot | 3 labeled examples + query |
| v3 | **Chain-of-Thought** (recommended) | Stepwise reasoning: journal → patterns → verdict |
| v4 | Multi-turn dialogue | Two-round: journal assessment → article assessment |

## Project Structure

```
retraction_screener/
├── pipeline.py               # 6-step pipeline orchestrator
├── ref_extractor.py          # Reference extraction
├── rw_matcher.py             # Retraction Watch database matcher
├── deepseek_classifier.py    # DeepSeek API classifier (v1-v4)
├── report_generator.py       # CSV/JSON report output
run_screener.py               # Command-line entry point
```

## Validation Results

| Metric | RW DB only | Full Pipeline |
|--------|:----------:|:-------------:|
| Sensitivity | 25.8% | **89.4%** |
| Specificity | 100% | **100%** |
| PPV | 100% | **100%** |
| NPV | 28.0% | **73.2%** |
| F1 Score | 41.0% | **94.4%** |

*Validation against 500 manually annotated references (388 retracted, 112 clean)*

## Data Sources

- **PubMed corpus**: 9,999 cancer/surgery systematic reviews (2020–2026)
- **Retraction Watch database**: 404 retracted articles
- **CrossRef**: 2,953 citation counts across 369 cited retracted articles
- **Gold standard**: 500 annotated references (3-layer annotation: RW DB → DeepSeek → manual PubMed verification)

## Citation

If you use this pipeline in your research, please cite:

```
Liu F, Xu C, Doi SA, Chu H, Liu H. DeepSeek large language model for automated
detection of retracted references in systematic reviews: a pipeline development
and diagnostic validation study. BMJ Evidence-Based Medicine. 2026.
```

## License

MIT © Eastern Hepatobiliary Surgery Hospital, Naval Medical University

## Contributing

Contributions are welcome. Please open an issue first to discuss proposed changes.
