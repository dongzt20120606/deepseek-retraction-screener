#!/usr/bin/env python3
"""Generate STARD 2015 participant flow diagram (Figure 5) for the DeepSeek Retraction Screener paper."""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pathlib import Path

# SVG font as editable text
plt.rcParams.update({
    'svg.fonttype': 'none',
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans', 'Segoe UI', 'sans-serif'],
})

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'figures'
OUT.mkdir(exist_ok=True)

# Colors
C_PRIMARY = '#003D6B'
C_SECONDARY = '#2E86C1'
C_ACCENT = '#E67E22'
C_GREEN = '#27AE60'
C_RED = '#D4380D'
C_BG = '#f8f9fa'

# ── Figure 5: STARD Flow Diagram ──
fig, ax = plt.subplots(1, 1, figsize=(9, 10.5))
ax.set_xlim(0, 9)
ax.set_ylim(0, 11)
ax.axis('off')

box_w, box_h = 3.2, 0.55
cx = 4.5  # center x

def draw_box(ax, x, y, w, h, text, color=C_PRIMARY, text_color='white', fontsize=8):
    box = FancyBboxPatch((x - w/2, y - h/2), w, h,
                         boxstyle="round,pad=0.08",
                         facecolor=color, edgecolor='white', linewidth=1.2, alpha=0.9)
    ax.add_patch(box)
    ax.text(x, y, text, ha='center', va='center',
            fontsize=fontsize, fontweight='bold', color=text_color)

def draw_arrow(ax, x1, y1, x2, y2, color='#666666', style='-'):
    ls = 'solid' if style == '-' else 'dashed'
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=color, lw=1.5, linestyle=ls))

def draw_exclusion(ax, y, text, x_offset, color='#888888'):
    """Draw an exclusion box to the right."""
    box = FancyBboxPatch((cx + box_w/2 + 0.3, y - 0.2), 3.0, 0.4,
                         boxstyle="round,pad=0.05",
                         facecolor='#f0f0f0', edgecolor='#cccccc', linewidth=1, linestyle='dashed')
    ax.add_patch(box)
    ax.text(cx + box_w/2 + 1.8, y, text, ha='center', va='center',
            fontsize=7, color=color, style='italic')

# ── Step 1: Search ──
y1 = 10.2
draw_box(ax, cx, y1, 3.5, 0.6, 'PubMed search (2020-2025)\nCancer/surgery systematic reviews', C_PRIMARY, 'white', 8)
draw_arrow(ax, cx, y1 - 0.35, cx, y1 - 0.8)

# Step 2: Retrieved
y2 = 9.0
draw_box(ax, cx, y2, 2.8, 0.5, f'Records identified (n = 55,361)', C_PRIMARY, 'white', 8)
draw_arrow(ax, cx, y2 - 0.3, cx, y2 - 0.7)

# Step 3: Sampled
y3 = 7.8
draw_box(ax, cx, y3, 3.0, 0.55, f'Systematic reviews sampled (n = 9,999)\n(with accessible PubMed metadata)', C_SECONDARY, 'white', 8)

# Exclusion: 45,362 not sampled
draw_exclusion(ax, y3, f'Excluded: n = 45,362\n(no reference list in PubMed XML)', '#888888')

draw_arrow(ax, cx, y3 - 0.32, cx, y3 - 0.7)

# Step 4: Reference extraction
y4 = 6.6
draw_box(ax, cx, y4, 3.0, 0.55, f'References extracted from 44 SR/MA\n(with accessible ReferenceList)', C_SECONDARY, 'white', 8)

# Exclusion: 9,955 no reference list
draw_exclusion(ax, y4, f'Excluded: n = 9,955\n(no ReferenceList in PubMed)', '#888888')

draw_arrow(ax, cx, y4 - 0.32, cx, y4 - 0.7)

# Step 5: Total references
y5 = 5.4
draw_box(ax, cx, y5, 2.8, 0.5, f'Total extracted references (n = 2,308)', C_ACCENT, 'white', 8)
draw_arrow(ax, cx, y5 - 0.3, cx, y5 - 0.7)

# Step 6: Positive control injection
y6 = 4.2
draw_box(ax, cx, y6, 3.2, 0.55, f'Positive controls injected (n = 100)\nknown retracted articles from RW database', C_ACCENT, 'white', 8)
draw_arrow(ax, cx, y6 - 0.32, cx, y6 - 0.7)

# Step 7: Final annotation set
y7 = 3.0
draw_box(ax, cx, y7, 2.8, 0.5, f'Final annotation set (n = 500)\n(100 positive + 400 background)', C_RED, 'white', 8.5)
draw_arrow(ax, cx, y7 - 0.3, cx, y7 - 0.65)

# Step 8: Gold standard annotation
y8 = 1.8
draw_box(ax, cx, y8, 4.5, 0.65, f'Gold standard annotation (three layers)\nLayer 1: RW DB + journal risk  |  Layer 2: DeepSeek API\nLayer 3: Manual PubMed verification by domain expert', C_GREEN, 'white', 7)

draw_arrow(ax, cx, y8 - 0.38, cx, y8 - 0.7)

# Step 9: Final
y9 = 0.6
draw_box(ax, cx, y9, 2.8, 0.5, f'Final gold standard (n = 500)\n388 retracted + 112 clean', C_PRIMARY, 'white', 8.5)

# ── Side annotations ──
# Right side: cumulative counts
annot_x = 8.0
annot_color = '#999999'
y_positions = [y3, y4, y6, y7, y9]
annotations = [
    'PMID batch download\nvia NCBI E-utilities',
    'PubMed XML ReferenceList\nparsing (44 SR/MA)',
    'Oversampling: 20%\nretracted target',
    'Balanced set\nfor validation',
    '0 UNCERTAIN\n100% labeled',
]
for yp, ann in zip(y_positions, annotations):
    ax.text(annot_x, yp, ann, ha='left', va='center', fontsize=6, color=annot_color, style='italic')

# Title
ax.set_title('Figure 5. STARD Flow Diagram — Participant Selection and Annotation Process',
             fontsize=10, fontweight='bold', pad=12, color=C_PRIMARY)

# Save
svg_path = OUT / 'fig5_stard_flowchart.svg'
png_path = OUT / 'fig5_stard_flowchart.png'
fig.savefig(str(svg_path), dpi=300, bbox_inches='tight')
fig.savefig(str(png_path), dpi=300, bbox_inches='tight')
plt.close()
print(f'STARD flow diagram saved: {svg_path}')
print(f'PNG preview: {png_path}')
