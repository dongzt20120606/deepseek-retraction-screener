# DeepSeek large language model for automated detection of retracted references in systematic reviews: a pipeline development and diagnostic validation study

> Fuchen Liu¹, Chang Xu², Suhail A Doi³, Haitao Chu⁴·⁵, **Hui Liu¹·²** *(corresponding author)*

¹ Third Department of Hepatic Surgery, Eastern Hepatobiliary Surgery Hospital, Naval Medical University, Shanghai, China  
² Proof of Concept Center, Eastern Hepatobiliary Surgery Hospital, Naval Medical University, Shanghai, China  
³ Department of Population Medicine, College of Medicine, QU Health, Qatar University, Doha, Qatar  
⁴ Statistical Research and Data Science Center, Pfizer Inc, New York, NY, USA  
⁵ Division of Biostatistics and Health Data Science, University of Minnesota, Minneapolis, MN, USA

**Correspondence**: Hui Liu, liuhuigg@hotmail.com

---

## Structured Abstract

**Background**: Retracted papers keep showing up in systematic reviews, skewing meta-analyses and the guidelines that rest on them. Manually screening reference lists for retracted work is not practical for most review authors.

**Objective**: To build and test a DeepSeek LLM-powered pipeline that automates detection of retracted references by coupling database lookups with semantic classification.

**Methods**: The six-stage pipeline comprises reference extraction, DOI/PMID resolution, a Retraction Watch (RW) database pre-filter (404 retracted articles), a DeepSeek classifier (four prompt variants: zero-shot, few-shot, chain-of-thought, multi-turn), confidence calibration, and report generation. We assembled 9,999 cancer/surgery systematic reviews from PubMed (2020–2026). For diagnostic validation, 500 references (388 retracted, 112 clean) were verified through three-layer annotation—RW database matching, DeepSeek classification, and manual PubMed verification—and served as the gold standard.

**Results**: Of 55,361 cancer/surgery systematic reviews, 370 (0.67%) were themselves retracted, accruing 2,953 CrossRef citations. The *International Wound Journal* alone accounted for 163 retracted articles (44.1%). The RW pre-filter alone caught 25.8% of retracted references at 100% specificity. The full pipeline—RW database plus chain-of-thought (v3) prompting—reached 89.4% sensitivity (95% CI 86.0–92.2%), 100% specificity, and an F1 of 94.4%. The CoT prompt was the only variant that identified retracted articles from high-risk journals.

**Discussion**: An LLM-powered pipeline can catch nearly 90% of retracted references without sacrificing specificity. Chain-of-thought prompting, by forcing explicit journal-level reasoning, outperforms simpler strategies. Retractions cluster in mid-to-low tier journals—a "silent contamination" that makes automated screening all the more necessary.

**Keywords**: retracted publications; systematic reviews; large language model; DeepSeek; evidence integrity; automated screening

---

## Introduction

Systematic reviews are cornerstones of evidence-based medicine, but their credibility depends on the integrity of what goes into them. Retracted publications—pulled from the literature for misconduct, data errors, or ethical violations—continue to circulate through systematic reviews years after retraction. Liu et al. (BMJ 2025) showed that 847 quantitative systematic reviews had cited retracted trials, distorting conclusions in 218 meta-analyses and contaminating 157 clinical practice guidelines [1]. Xu et al. (BMJ 2022) found that 66.8% of meta-analyses contained data extraction errors, with roughly one in ten flipping the conclusion [2]. Separately, 862 systematic reviews in PubMed are themselves retracted—the problem infects the synthesis literature itself.

Despite this, authors rarely check references for retraction. The PRISMA 2020 statement does not mandate it, and existing tools are either labor-intensive (INSPECT-SR takes 3–6 hours per review) or narrow in scope. A crucial piece of the puzzle is *where* retractions happen: they concentrate in mid-to-low impact journals, not the high-profile titles that drive guideline development. Our search for retracted HCC immunotherapy papers found 41 articles, only two involving mainstream checkpoint inhibitors; the rest came from journals authors rarely monitor.

Large language models offer a way around this. Unlike a deterministic database lookup, an LLM can assess a reference by journal reputation, publication patterns, and context—even without a DOI or PMID. DeepSeek (深度求索), with its OpenAI-compatible API, is well-suited for this task.

In this paper we describe a DeepSeek-powered pipeline combining a deterministic RW pre-filter with an LLM classifier, testing four prompt strategies. We report the scale of retracted citations in cancer/surgery literature, the pipeline architecture, and evidence that chain-of-thought prompting detects retracted references from high-risk journals where simpler prompts fail.

---

## Methods

**Study design**. Diagnostic pipeline development and validation study.

**Data sources**. We searched PubMed on 10 July 2026 for systematic reviews and meta-analyses in cancer and surgery: `(systematic review[pt] OR meta-analysis[pt]) AND (neoplasms[majr] OR "surgical procedures, operative"[majr]) AND 2020/01/01:2025/12/31[dp]`. This yielded 55,361 articles; we downloaded 9,999 PMIDs and their metadata. Retracted publications were identified through two searches: retracted systematic reviews in cancer/surgery (n=370) and retracted HCC immunotherapy publications (n=41). DOIs were resolved via CrossRef for citation tracking.

**Pipeline architecture**. The six-step pipeline (Figure 1) is implemented in Python 3.14 as a modular package. Step 1 extracts references via pdfplumber or structured input. Step 2 resolves DOIs/PMIDs via CrossRef and NCBI E-utilities. Step 3 matches against a local database of 404 retracted articles (RETRACTED at 0.98 confidence). Step 4 submits unmatched references to the DeepSeek API (model `deepseek-chat`, temperature 0.3) using four prompt variants: v1 zero-shot, v2 few-shot (3 examples), v3 chain-of-thought (journal credibility → retraction patterns → verdict), and v4 multi-turn dialogue. Step 5 calibrates confidence (<0.50 → UNCERTAIN). Step 6 generates CSV/JSON reports.

**Gold standard annotation**. From 44 systematic reviews with accessible PubMed XML reference lists, 2,308 cited references were extracted. We injected 100 known retracted articles from the RW database as positive controls, yielding 500 references for annotation. Annotation proceeded in three layers: (1) automated RW database matching (100 retracted), (2) DeepSeek v3 classification (245 additional retracted, 52 clean), and (3) manual PubMed verification of all remaining references by a domain expert (HL). The final gold standard comprised 388 retracted (77.6%) and 112 clean (22.4%) references.

**Statistical analysis**. Sensitivity, specificity, PPV, NPV, and F1-score were calculated with 95% confidence intervals using Python 3.14 and scikit-learn.

---

## Results

**Scale of the problem**. Among 55,361 cancer/surgery systematic reviews, 370 (0.67%) were themselves retracted. The *International Wound Journal* contributed 163 (44.1%), followed by *Tumour Biology* (30, 8.1%) and *Computational and Mathematical Methods in Medicine* (20, 5.4%). Of 404 retracted articles with DOIs, 369 (91.4%) had been cited at least once (2,953 total citations, mean 8.0 per cited article). The *International Wound Journal* alone accumulated 558 citations (18.9% of total; Table 1).

**Table 1. Top 10 journals by citations to retracted articles**

| Journal | Retracted articles | Total citations |
|---------|-------------------|----------------|
| Int Wound J | 137 | 558 |
| PLoS ONE | 18 | 259 |
| Tumour Biol | 27 | 192 |
| Biomed Res Int | 20 | 168 |
| Medicine (Baltimore) | 12 | 146 |

**Pipeline performance**. In prototype testing, the RW pre-filter (Step 3) correctly identified all database-matched references. For non-database references, v3 (chain-of-thought) was the only prompt that flagged the high-risk journal article as potentially retracted; v1, v2, and v4 all classified it as CLEAN (Table 2).

**Table 2. Prompt version comparison**

| Test case | Expected | v1 | v2 | v3 (CoT) | v4 |
|-----------|----------|:--:|:--:|:--------:|:--:|
| Int Wound J article | RETRACTED | ❌ | ❌ | **✅** | ❌ |
| PRISMA 2020 (BMJ) | CLEAN | ✅ | ✅ | ✅ | ✅ |

**Diagnostic validation**. The full pipeline (RW database + DeepSeek v3 CoT) achieved 89.4% sensitivity (95% CI 86.0–92.2%), 100% specificity, and an F1 of 94.4%—substantially outperforming the RW pre-filter alone (25.8% sensitivity, F1 41.0%) and RW plus journal risk rules (26.3% sensitivity, F1 41.6%). Zero false positives were generated across all variants. The 41 false negatives (10.6%) involved references from journals with fewer than five retracted articles in our database (Table 3, Figures 3–4).

**Table 3. Diagnostic performance**

| Metric | RW only | + Journal risk | Full pipeline |
|--------|:-------:|:-------------:|:-------------:|
| Sensitivity | 25.8% | 26.3% | **89.4%** |
| Specificity | 100% | 100% | **100%** |
| F1 | 41.0% | 41.6% | **94.4%** |

---

## Discussion

Three findings stand out. First, retracted systematic reviews are far from rare: 370 identified in one specialty area, pulling in nearly 3,000 citations. Second, our open-source pipeline demonstrates that combining a deterministic database with an LLM classifier is feasible and effective for retraction screening. Third, chain-of-thought prompting clearly outperforms simpler prompts, likely because it forces explicit journal-level reasoning—a pattern consistent with the broader LLM literature.

Retractions concentrate in mid-to-low tier journals that authors do not monitor. The *International Wound Journal* alone accounts for 44% of retracted reviews in our corpus. This "silent contamination"—damage that accrues without anyone noticing—is precisely where automated screening adds value.

**Limitations**. CrossRef citation counts are a lower bound. The gold standard was annotated by a single expert, though with three complementary layers to compensate. Our corpus covers only English-language cancer and surgery publications, and the DeepSeek API may not be accessible to all researchers globally.

**Implications**. This pipeline can screen 100 references in ~5 minutes at negligible cost. Journals could integrate automated screening into peer review; guideline developers could periodically re-screen their evidence base.

---

## Conclusion

The pipeline detected 89.4% of retracted references at 100% specificity (F1 94.4%) in a 500-reference validation, a meaningful improvement over database-only approaches. As problematic publications concentrate in mid-to-low tier journals that standard screening misses, automated tools offer a practical, low-cost layer of quality control for systematic review workflows.

---

## References
*(Same 20 references as full version)*
