# BMJ Evidence-Based Medicine — 投稿格式检查清单

## 目标期刊确认

| 项目 | 数据 |
|:----|:------|
| **期刊名称** | BMJ Evidence-Based Medicine (BMJ EBM) |
| **影响因子** | 10.8 |
| **文章类型** | Original Research (Evidence: evidence synthesis content) |
| **投稿系统** | ScholarOne (https://mc.manuscriptcentral.com/bmjebm) |
| **APC (开放获取)** | £4,370 (可选) |

---

## ✅ 格式检查清单

### 基本格式

| 要求 | 状态 | 操作 |
|:----|:----:|:----|
| Word 文件 (.docx) | ✅ | `paper_draft.docx` 已准备 |
| 标题含研究问题+设计 | ⚠️ | 当前标题符合要求 |
| 单栏、单倍行距、10号字体 | ⬜ | 需调整格式 |
| ORCID (通讯作者) | ⬜ | 需注册 ORCID |
| 所有作者的姓名/邮箱/单位 | ⬜ | 需补充作者列表 |

### 结构要求

| 部分 | 要求 | 操作 |
|:----|:----|:----|
| 标题页 | 所有作者姓名、地址、邮箱、电话 | ⬜ 需创建 |
| 结构化摘要 (250-300词) | Objective, Design, Setting, Participants, Interventions, Main outcome measures, Results, Conclusions, Registration | ✅ `paper_draft.md` 已有，需调整到300词以内 |
| Key Messages框 | 3个问题（已知/新增/影响），3-5句话 | ✅ 已在 Cover Letter 中，需插入到论文中 |
| 正文 (≤4,000词) | Introduction → Methods → Results → Discussion → Conclusion | ✅ 当前~4,200词，需精简约200词 |
| 图表 (≤5个) | Fig 1-5 = 5张图 | ✅ 刚好5张 |
| 参考文献 (无限制) | 20条 | ✅ |
| 患者与公众参与声明 (PPI) | Methods 末尾 | ⬜ 需添加 N/A 声明 |
| 数据共享声明 | 结论前 | ⬜ 需添加 |
| 利益冲突声明 | Acknowledgments前 | ✅ 已在论文中 |
| 资助声明 | Acknowledgments前 | ✅ 已在论文中 |
| STARD 核对表 | 作为补充材料上传 | ✅ Table S4 已准备 |
| ORCID (通讯作者) | 提交时在 ScholarOne 中填写 | ⬜ 需注册 |

### 图表格式

| 要求 | 状态 |
|:----|:----:|
| SVG 矢量图 | ✅ 全部可编辑 |
| 分辨率 ≥300dpi | ✅ 300dpi |
| RGB 色彩模式 | ✅ |
| 单独文件上传 | ⬜ 需从 Word 分离 |

---

## 投稿前步骤

- [ ] **注册 ORCID** (https://orcid.org) — 通讯作者必须
- [ ] **精简论文正文 200 词** (当前 4,200 → 目标 4,000 以内)
- [ ] **调整摘要至 300 词以内** (BMJ EBM 结构化摘要格式)
- [ ] **插入 Key Messages 框** (摘要之后)
- [ ] **添加 PPI 声明** (Methods 末尾): "No patients were involved in this study as it is a bibliometric and computational analysis of published literature."
- [ ] **创建标题页** (单独 Word 文件或放在正文前)
- [ ] **分离图文件** (5 张图作为单独文件上传)
- [ ] **补充 STARD 核对表** (Table S4)
- [ ] **补充 OSF DOI** (注册完成后填入)
- [ ] **作者贡献声明** (CRediT 格式)
- [ ] **通讯作者信息完整**
