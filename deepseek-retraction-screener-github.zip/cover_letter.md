# Cover Letter — BMJ Evidence-Based Medicine

---

**Date:** [Date of submission]

**To:** The Editor-in-Chief, BMJ Evidence-Based Medicine

**Re:** "DeepSeek large language model for automated detection of retracted references in systematic reviews: a diagnostic validation study"

---

Dear Editor,

I am pleased to submit our manuscript entitled "DeepSeek large language model for automated detection of retracted references in systematic reviews: a diagnostic validation study" for consideration as an Original Research article in BMJ Evidence-Based Medicine.

**Why this study matters**

Retracted publications continue to circulate through systematic reviews long after their withdrawal, distorting meta-analytic conclusions and potentially contaminating clinical practice guidelines. Liu et al. (BMJ, 2025) recently demonstrated that 847 systematic reviews have cited retracted trials, distorting 218 meta-analyses and contaminating 157 guidelines. Yet systematic review authors rarely check their reference lists manually—PRISMA 2020 does not mandate retraction checking, and existing tools are either labour-intensive or limited in scope.

**What we did and what we found**

We developed and validated a six-stage automated screening pipeline that combines a deterministic Retraction Watch database pre-filter with a DeepSeek large language model (LLM) classifier. Against a 500-reference gold standard (constructed through three independent annotation layers: database matching, LLM classification, and manual PubMed verification), the full pipeline achieved:

- **Sensitivity: 89.4%** (95% CI 86.0–92.2%)
- **Specificity: 100%** (95% CI 96.8–100%)
- **F1 score: 94.4%**
- **Zero false positives**

We also demonstrated that chain-of-thought prompting substantially outperforms simpler prompt strategies for detecting retracted articles from high-risk journals—a finding with practical implications for deploying LLMs in evidence integrity workflows.

**Why BMJ Evidence-Based Medicine**

We believe this manuscript is a strong fit for BMJ EBM for three reasons:

1. **Methodological relevance**: The paper addresses a core EBM problem—evidence contamination—with a practical, scalable methodological solution. BMJ EBM's focus on "tools, methods, and concepts central to practising evidence-based medicine" aligns directly with our contribution.

2. **Clinical urgency**: The "silent contamination" problem—retractions concentrated in mid-to-low tier journals that authors rarely monitor—has direct implications for the trustworthiness of evidence synthesis that informs clinical decision-making.

3. **Novelty and reproducibility**: This is, to our knowledge, the first diagnostic validation of an LLM-powered retraction screening pipeline against a rigorously constructed, multi-layer gold standard. All code, data, and interactive verification tools are openly available.

**What this manuscript adds**

| What is already known | What this study adds |
|-----------------------|---------------------|
| Retracted publications contaminate systematic reviews | An automated pipeline combining database matching with LLM classification detects 89.4% of retracted references at 100% specificity |
| Manual screening is time-prohibitive | The pipeline can screen 100 references in approximately 5 minutes at negligible API cost |
| Chain-of-thought prompting improves LLM reasoning on classification tasks | CoT prompting uniquely identifies retracted articles from high-risk journals where simpler prompts fail |

**Additional information**

- This study was conducted in accordance with the STARD 2015 checklist for diagnostic accuracy studies (see Supplementary Table S4 and Figure 5).
- The study has been registered on the Open Science Framework ([DOI to be added upon completion of registration]).
- All authors have reviewed and approved the manuscript. None of the authors have competing interests relevant to this work, except HL who has received speaking honoraria from DeepSeek for educational presentations on AI in clinical research.

We hope you find this work suitable for publication in BMJ Evidence-Based Medicine and look forward to your response.

Yours sincerely,

[Your Name], MD, PhD
[Department]
[Institution]
[Email]
[ORCID]

**Corresponding author:** [Name, address, email, phone]

---

## Key Messages (for the manuscript itself — copy to paper)

### What is already known on this topic
- Retracted publications continue to be cited in systematic reviews, distorting meta-analytic conclusions.
- Systematic review authors rarely check references for retraction status due to the labour-intensive nature of manual verification.
- Existing automated tools are limited to deterministic database lookups that capture only a minority of retracted references.

### What this study adds
- A two-stage pipeline combining Retraction Watch database matching with a DeepSeek LLM classifier achieved 89.4% sensitivity at 100% specificity (F1 = 94.4%) against a 500-reference gold standard.
- Chain-of-thought prompting was the only prompt strategy that correctly identified retracted articles from high-risk journals.
- The RW database alone captured only 25.8% of retracted references; the LLM classifier tripled detection.

### How this study might affect research, practice or policy
- Systematic review authors can integrate this pipeline into their workflow to screen 100 references in approximately 5 minutes.
- Journals and guideline developers may consider automated retraction screening as a standard quality control step.
- The findings support chain-of-thought prompting as the default strategy for LLM-based evidence integrity tools.
