#!/usr/bin/env python3
"""
DeepSeek Retraction Screener — Main Entry Point

Usage:
    python run_screener.py                         # Run with synthetic test data
    python run_screener.py --pdf path/to/paper.pdf  # Screen a real paper PDF
    python run_screener.py --refs input_refs.csv    # Screen references from CSV
    python run_screener.py --prompt v3              # Use specific prompt version

Output: output/screening_report.csv
"""

import csv, json, os, sys, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from retraction_screener.pipeline import RetractionScreener
from retraction_screener.ref_extractor import ReferenceExtractor
from retraction_screener.report_generator import ReportGenerator

def main():
    parser = argparse.ArgumentParser(description='DeepSeek Retraction Screener')
    parser.add_argument('--pdf', help='Path to a paper PDF to screen')
    parser.add_argument('--refs', help='CSV file with references (columns: title, authors, journal, year, doi, pmid)')
    parser.add_argument('--prompt', default='v3', choices=['v1', 'v2', 'v3', 'v4'],
                        help='DeepSeek prompt engineering version')
    parser.add_argument('--output', default='output', help='Output directory')
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    # ── Initialize pipeline ──
    screener = RetractionScreener(data_dir='data')
    extractor = ReferenceExtractor()
    reporter = ReportGenerator()

    # ── Load references ──
    references = []
    source_desc = ''

    if args.pdf:
        print(f'\n📄 Extracting references from PDF: {args.pdf}')
        result = extractor.extract_from_pdf(args.pdf)
        raw_refs = result['references_raw']
        print(f'  Extracted {len(result["references_raw"])} raw references from {result["n_pages"]} pages')

        # Convert raw reference strings to structured format
        for i, raw in enumerate(raw_refs):
            references.append({
                'raw_text': raw,
                'title': f'[Reference {i+1}]',
                'authors': '',
                'journal': '',
                'year': '',
                'doi': '',
                'pmid': '',
            })
        source_desc = f'PDF ({args.pdf})'

    elif args.refs:
        print(f'\n📋 Loading references from CSV: {args.refs}')
        with open(args.refs, encoding='utf-8') as f:
            references = list(csv.DictReader(f))
        print(f'  Loaded {len(references)} references')
        source_desc = f'CSV ({args.refs})'

    else:
        print('\n🧪 Running with synthetic test references')
        references = extractor.create_synthetic_references(include_retracted=True)
        source_desc = 'synthetic test data'

    print(f'\n{"="*60}')
    print(f'DeepSeek Retraction Screener — Pipeline Run')
    print(f'Source: {source_desc}')
    print(f'Prompt version: {args.prompt}')
    print(f'References to screen: {len(references)}')
    print(f'{"="*60}\n')

    # ── Run the pipeline ──
    csv_out = os.path.join(args.output, 'screening_report.csv')
    json_out = os.path.join(args.output, 'screening_report.json')

    results = screener.run_pipeline(references, output_path=csv_out)

    # ── Print summary ──
    print()
    screener.print_summary(results)

    # ── Save JSON ──
    reporter.save_json(results, json_out)

    # ── Print summary table for paper ──
    print()
    print(reporter.generate_summary_table(results))


if __name__ == '__main__':
    main()
