"""
Phase 1, Task A: Download PMID lists from PubMed via E-utilities
Target: Cancer/surgery systematic reviews and meta-analyses (2020-2025)

Two searches:
  1. All cancer/surgery SR/MA  → for building the reference corpus
  2. Retracted cancer/surgery SR/MA → for positive sample enrichment

Output: data/raw/pmids_all.txt, data/raw/pmids_retracted.txt
"""

import urllib.request
import xml.etree.ElementTree as ET
import time
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(BASE_DIR, 'data', 'raw')
os.makedirs(RAW_DIR, exist_ok=True)

def fetch_pmids(webenv, query_key, total_count, retmax=5000, label=""):
    """Batch download PMIDs using PubMed history server."""
    all_ids = []
    for start in range(0, min(total_count, 10000), retmax):  # limit to 10k for now
        url = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
            f"?db=pubmed&WebEnv={webenv}&query_key={query_key}"
            f"&retmax={retmax}&retstart={start}&retmode=xml&rettype=uilist"
        )
        req = urllib.request.Request(url, headers={'User-Agent': 'DeepSeekRetractionStudy/1.0'})
        try:
            resp = urllib.request.urlopen(req, timeout=60)
            xml_data = resp.read()
            root = ET.fromstring(xml_data)
            batch_ids = [id_elem.text for id_elem in root.findall('.//Id')]
            all_ids.extend(batch_ids)
            print(f"  [{label}] Batch {start//retmax + 1}: got {len(batch_ids)} PMIDs (total: {len(all_ids)})")
        except Exception as e:
            print(f"  [{label}] ERROR at batch {start//retmax + 1}: {e}")
        time.sleep(0.5)  # rate limit courtesy
    return all_ids

# ── Search 1: All cancer/surgery SR/MA ──
print("=" * 60)
print("Search 1: Cancer/surgery systematic reviews (2020-2025)")
print("Total: 55,361 articles")
all_pmids = fetch_pmids(
    webenv="MCID_6a5051ace5aed92fb30e969c",
    query_key="1",
    total_count=55361,
    label="ALL"
)

# Save
outpath = os.path.join(RAW_DIR, 'pmids_cancer_sr_ma.txt')
with open(outpath, 'w') as f:
    f.write('\n'.join(all_pmids))
print(f"\nSaved {len(all_pmids)} PMIDs to {outpath}")

# ── Search 2: Retracted SR/MA in cancer/surgery ──
# (We'll run a separate search since the WebEnv changes)
# Note: Total retracted in cancer/surgery = 370

print("\n" + "=" * 60)
print("Search 2 will be run separately via a new WebEnv query")
print("Completed Search 1. Retracted PMIDs already known from earlier search.")
print("=" * 60)
