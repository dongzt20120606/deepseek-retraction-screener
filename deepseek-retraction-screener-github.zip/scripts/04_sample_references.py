"""
Phase 3 Prep: Sample 300-500 references from 9,999 SR/MA reference lists.
1. Randomly sample ~30 SR/MAs (stratified by year)
2. Fetch full PubMed XML with ReferenceList
3. Extract all cited references
4. Cross-reference with RW database
5. Save annotation-ready dataset
"""

import csv, json, os, random, time, re
import urllib.request
import xml.etree.ElementTree as ET

random.seed(42)  # reproducible sampling

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if '__file__' in dir() else os.getcwd()
DATA_DIR = os.path.join(BASE, 'data')
OUT_DIR = os.path.join(BASE, 'data', 'processed')
os.makedirs(OUT_DIR, exist_ok=True)

# ── 1. Load corpus and sample SR/MAs (prioritize OA for better ref list coverage) ──
with open(os.path.join(DATA_DIR, 'processed', 'metadata_all.csv'), encoding='utf-8') as f:
    corpus = list(csv.DictReader(f))

# Prioritize articles from open-access journals (more likely to have ref lists in PubMed)
oa_keywords = ['bmc', 'plos one', 'plos', 'front', 'mdpi', 'springer', 'wiley', 'bmj open',
               'j clin med', 'cancers', 'int j mol sci', 'diagnostics', 'j clin med',
               'medicine', 'sci rep', 'nature', 'cell', 'ieee']
oa_corpus = [r for r in corpus if any(k in (r.get('journal_iso','')+r.get('journal_full','')).lower() for k in oa_keywords)]
non_oa = [r for r in corpus if r not in oa_corpus]

# Stratified by year
by_year_oa = {}
for r in oa_corpus:
    by_year_oa.setdefault(r.get('year','unknown'), []).append(r)
by_year_noa = {}
for r in non_oa:
    by_year_noa.setdefault(r.get('year','unknown'), []).append(r)

samples_per_year = {'2024': 3, '2025': 15, '2026': 12}
selected = []
for yr, n in samples_per_year.items():
    pool = by_year_oa.get(yr, [])
    if pool:
        selected.extend(random.sample(pool, min(n, len(pool))))
    # Also add some non-OA for diversity
    pool2 = by_year_noa.get(yr, [])
    if pool2:
        selected.extend(random.sample(pool2, min(n//2, len(pool2))))

print(f'Selected {len(selected)} SR/MAs for reference extraction ({len([r for r in selected if r in oa_corpus])} OA)')
for r in selected[:5]:
    print(f'  PMID {r["pmid"]}: {r["year"]} | {r["journal_iso"][:25]} | {r["title"][:60]}')

# ── 2. Fetch full XML with ReferenceList ──
def fetch_references(pmids):
    """Fetch ReferenceList for a batch of PMIDs via efetch."""
    url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=' + ','.join(pmids) + '&retmode=xml'
    resp = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent':'Study/1.0'}), timeout=90)
    return resp.read()

def parse_references(xml_data, parent_pmid):
    """Extract references from PubmedData > ReferenceList."""
    refs = []
    root = ET.fromstring(xml_data)
    
    for article in root.findall('.//PubmedArticle'):
        # Get the PMID of this article (the parent)
        a_pmid = ''
        m = article.find('.//MedlineCitation/PMID')
        if m is not None and m.text:
            a_pmid = m.text
        
        # Only process if this is one of our selected articles
        if a_pmid != parent_pmid:
            continue
        
        # Get ReferenceList
        ref_list = article.find('.//PubmedData/ReferenceList')
        if ref_list is None:
            continue
        
        for ref in ref_list.findall('./Reference'):
            citation = ref.find('./Citation')
            citation_text = ''.join(citation.itertext()).strip() if citation is not None else ''
            
            # Try to get PMID of the cited article
            ref_pmid = ''
            article_id_list = ref.find('./ArticleIdList')
            if article_id_list is not None:
                for aid in article_id_list.findall('./ArticleId'):
                    if aid.get('IdType') == 'pubmed':
                        ref_pmid = aid.text or ''
                        break
            
            refs.append({
                'parent_pmid': a_pmid,
                'cited_pmid': ref_pmid,
                'citation': citation_text[:300],
            })
    
    return refs

# ── 3. Process in batches ──
all_refs = []
BATCH = 5  # 5 at a time to avoid timeout

for i in range(0, len(selected), BATCH):
    batch = selected[i:i+BATCH]
    pmids = [r['pmid'] for r in batch]
    print(f'\nFetching batch {i//BATCH + 1}/{(len(selected)-1)//BATCH + 1}: PMIDs {pmids}', flush=True)
    
    try:
        xml_data = fetch_references(pmids)
        
        for r in batch:
            refs = parse_references(xml_data, r['pmid'])
            all_refs.extend(refs)
            print(f'  PMID {r["pmid"]}: {len(refs)} references extracted')
        
        time.sleep(0.5)
    except Exception as e:
        print(f'  ERROR: {e}')
        time.sleep(2)
        continue

print(f'\nTotal references extracted: {len(all_refs)}')

# ── 4. Load RW database for cross-referencing ──
rw_db = {}
rw_articles = []  # Full list for positive control injection
rw_path = os.path.join(DATA_DIR, 'processed', 'retraction_citation_check.csv')
if os.path.exists(rw_path):
    with open(rw_path, encoding='utf-8') as f:
        for row in csv.DictReader(f):
            doi = row.get('doi', '').strip().lower()
            pmid = row.get('pmid', '').strip()
            if doi: rw_db[doi] = row
            if pmid: rw_db[pmid] = row
            rw_articles.append(row)

# Also load the RW metadata for positive controls
sr_meta_path = os.path.join(DATA_DIR, 'processed', 'retracted_sr_ma_meta.csv')
rw_positive_controls = []
if os.path.exists(sr_meta_path):
    with open(sr_meta_path, encoding='utf-8') as f:
        for row in csv.DictReader(f):
            rw_positive_controls.append({
                'parent_pmid': 'POSITIVE_CONTROL',
                'cited_pmid': row['pmid'],
                'citation': f"{row.get('title','')}. {row.get('journal','')}. {row.get('year','')}.",
            })

# ── 5. Sample references for annotation ──
# First: mark which extracted refs match the RW DB
for r in all_refs:
    pmid = r.get('cited_pmid', '')
    r['rw_match'] = 'RETRACTED' if pmid in rw_db else 'UNKNOWN'

retracted_refs = [r for r in all_refs if r['rw_match'] == 'RETRACTED']
other_refs = [r for r in all_refs if r['rw_match'] == 'UNKNOWN']

# Inject positive controls from RW metadata (ensuring enough retracted samples)
n_positive_controls = min(100, len(rw_positive_controls))
positive_controls = random.sample(rw_positive_controls, n_positive_controls)
for pc in positive_controls:
    pc['rw_match'] = 'RETRACTED'

# Build balanced annotation set
n_retracted = len(retracted_refs) + len(positive_controls)
n_other_target = max(300, min(400, len(other_refs)))

sampled_retracted = retracted_refs + positive_controls
sampled_other = random.sample(other_refs, min(n_other_target, len(other_refs))) if other_refs else []

annotation_set = sampled_retracted + sampled_other
random.shuffle(annotation_set)

print(f'\n{"="*50}')
print(f'Annotation Dataset Summary')
print(f'{"="*50}')
print(f'Total extracted references: {len(all_refs)}')
print(f'  Matched in RW DB: {len(retracted_refs)}')
print(f'  Positive controls injected: {len(positive_controls)}')
print(f'  Not in RW DB:     {len(other_refs)}')
print(f'')
print(f'Final annotation set: {len(annotation_set)}')
retracted_count = sum(1 for r in annotation_set if r.get('rw_match') == 'RETRACTED')
print(f'  Known retracted:  {retracted_count} ({retracted_count*100//len(annotation_set)}%)')
print(f'  Otherwise:        {len(annotation_set)-retracted_count}')

# ── 6. Save ──
# Full extraction
full_path = os.path.join(OUT_DIR, 'extracted_references_all.json')
with open(full_path, 'w', encoding='utf-8') as f:
    json.dump(all_refs, f, indent=2, ensure_ascii=False)
print(f'\nFull references saved: {full_path}')

# Annotation sample
annot_path = os.path.join(OUT_DIR, 'annotation_sample_500.json')
with open(annot_path, 'w', encoding='utf-8') as f:
    json.dump(annotation_set, f, indent=2, ensure_ascii=False)

# Also save as CSV for easy review
annot_csv = os.path.join(OUT_DIR, 'annotation_sample_500.csv')
with open(annot_csv, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['parent_pmid', 'cited_pmid', 'citation', 'rw_match'])
    w.writeheader()
    for r in annotation_set:
        w.writerow({'parent_pmid': r['parent_pmid'], 'cited_pmid': r.get('cited_pmid',''),
                     'citation': r['citation'][:200], 'rw_match': r.get('rw_match', 'UNKNOWN')})

print(f'Annotation sample saved: {annot_csv}')
print(f'  Citations: {annot_path}')
