#!/usr/bin/env python3
"""Generate STARD 2015 checklist table (Table S4) for the DeepSeek Retraction Screener paper."""

import csv, os
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
SUPP = BASE / 'supplementary'
SUPP.mkdir(exist_ok=True)

# STARD 2015 — 30 items
stard = [
    (1, "TITLE OR ABSTRACT", "Identification as a study of diagnostic accuracy", "Title and Abstract: 'diagnostic validation'"),
    (2, "INTRODUCTION", "Structured summary of study design, methods, results, conclusions", "Structured Abstract (Background, Objective, Methods, Results, Discussion)"),
    (3, "INTRODUCTION", "Scientific and clinical background, including intended use and clinical role", "Introduction, paragraphs 1-4"),
    (4, "INTRODUCTION", "Study objectives and hypotheses", "Introduction, final paragraph"),
    (5, "METHODS", "Whether data collection was planned before the index test and reference standard were performed (prospective vs retrospective)", "Retrospective diagnostic validation study (stated in Methods, Study Design)"),
    (6, "METHODS", "Eligibility criteria", "44 SR/MA from 9,999 PMID sample with accessible ReferenceList in PubMed XML; 21 journals; oncology/surgery domains (stated in Gold Standard Annotation)"),
    (7, "METHODS", "On what basis potentially eligible participants were identified", "PubMed search: 55,361 SR/MA → 9,999 downloaded → 44 with reference lists → 2,308 refs (STARD flow diagram, Figure 5)"),
    (8, "METHODS", "Where and when participants were identified (setting, location, dates)", "PubMed, 10 July 2026; 2020-2025 publication window (stated in Data Sources)"),
    (9, "METHODS", "Whether participants formed a consecutive, random, or convenience series", "Convenience sample of reviews with accessible PubMed XML ReferenceList (stated in Gold Standard Annotation)"),
    (10, "METHODS", "Index test, in sufficient detail to allow replication", "DeepSeek API (deepseek-chat, temp=0.3), 4 prompt variants, 6-step pipeline (stated in Pipeline Architecture, Figures 1-2)"),
    (11, "METHODS", "Rationale for index test components", "Two-stage design: RW DB for high-specificity pre-filter, LLM for semantic classification of unmatched refs (stated in Pipeline Architecture)"),
    (12, "METHODS", "Reference standard and its rationale", "Multi-layer: RW DB + journal risk + DeepSeek API + manual PubMed verification by domain expert (stated in Gold Standard Annotation)"),
    (13, "METHODS", "Rationale for choosing the reference standard", "No single authoritative retraction database; combined approach maximises coverage (stated in Gold Standard Annotation)"),
    (14, "METHODS", "Definition of and rationale for test positivity cut-offs or result categories", "RETRACTED / CLEAN / UNCERTAIN; confidence <0.50 → UNCERTAIN (stated in Steps 4-5)"),
    (15, "METHODS", "Whether clinical information and reference standard results were available to the index test operators", "DeepSeek API received only citation text, blind to gold standard labels (stated in Blinding and Reproducibility)"),
    (16, "METHODS", "Methods for estimating or comparing measures of diagnostic accuracy", "Sensitivity, Specificity, PPV, NPV, F1-score, 95% Wilson CI (stated in Statistical Analysis)"),
    (17, "METHODS", "How indeterminate index test results were handled", "Uncertain results (confidence <0.50) excluded from diagnostic metric calculation (stated in Step 5)"),
    (18, "METHODS", "How missing data on the index test or reference standard were handled", "N/A — complete data on all 500 samples"),
    (19, "METHODS", "Any analyses of variability in diagnostic accuracy (subgroup analyses)", "Comparison across 4 prompt versions and 3 pipeline variants (stated in Results)"),
    (20, "METHODS", "Intended sample size and how it was determined", "n=500; 100+ positive cases needed for ±10% CI precision at 85% sensitivity (stated in Sample Size)"),
    (21, "RESULTS", "Flow of participants, using a diagram", "STARD flow diagram (Figure 5)"),
    (22, "RESULTS", "Baseline demographic and clinical characteristics of participants", "44 SR/MA: 26 oncology, 12 surgery, 6 combined; 21 journals (stated in Gold Standard Annotation)"),
    (23, "RESULTS", "Distribution of severity of disease or alternative diagnoses", "388/500 (77.6%) retracted, 112/500 (22.4%) clean in gold standard"),
    (24, "RESULTS", "Cross-tabulation of index test results by reference standard", "Table 3: confusion matrix; Figure 4: heatmap"),
    (25, "RESULTS", "Estimates of diagnostic accuracy and their precision", "Table 3: Sens 89.4% (86.0-92.2), Spec 100% (96.8-100), PPV 100%, NPV 73.2%, F1 94.4%"),
    (26, "RESULTS", "Any adverse events from performing the index test", "N/A — no human participants"),
    (27, "DISCUSSION", "Study limitations, including sources of potential bias and statistical uncertainty", "Limitations section (single annotator, CrossRef lower bound, pdfplumber limits, English-only)"),
    (28, "DISCUSSION", "Implications for practice, including intended use and clinical role", "Implications for Practice section"),
    (29, "OTHER INFORMATION", "Registration number and name of registry", "OSF retrospective registration: https://osf.io/XXXXXXXX (stated in Registration and Protocol)"),
    (30, "OTHER INFORMATION", "Where the full study protocol can be accessed", "GitHub repository (stated in Data Availability)"),
    (31, "OTHER INFORMATION", "Sources of funding and other support; role of funders", "No specific funding was received for this study (stated in Competing Interests)"),
]

# Save
csv_path = SUPP / 'Table_S4_STARD_2015.csv'
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['Section/Topic', '#', 'Item', 'Location in manuscript'])
    for num, section, item, location in stard:
        w.writerow([section, num, item, location])

print(f'Saved: {csv_path} ({len(stard)} items)')
