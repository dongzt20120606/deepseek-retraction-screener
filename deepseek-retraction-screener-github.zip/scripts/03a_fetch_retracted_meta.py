"""
Step 3A: Fetch metadata for retracted articles (370 SR/MA + 41 HCC immunotherapy)
"""
import urllib.request, xml.etree.ElementTree as ET, csv, time, os, re

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if '__file__' in dir() else os.getcwd()
RAW = os.path.join(BASE, 'data', 'raw')
OUT = os.path.join(BASE, 'data', 'processed')
os.makedirs(OUT, exist_ok=True)

def fetch_metadata(pmids, label=''):
    """Batch fetch metadata for a list of PMIDs via efetch XML."""
    rows = []
    BATCH = 200
    for i in range(0, len(pmids), BATCH):
        batch = pmids[i:i+BATCH]
        url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=' + ','.join(batch) + '&retmode=xml'
        resp = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent':'Study/1.0'}), timeout=60)
        root = ET.fromstring(resp.read())
        for article in root.findall('.//PubmedArticle'):
            m = article.find('.//MedlineCitation')
            pmid = m.find('./PMID').text if m is not None and m.find('./PMID') is not None else ''
            art = m.find('./Article') if m is not None else None
            title = ' '.join(art.find('./ArticleTitle').itertext()).replace('\n',' ').replace('\r','') if art is not None and art.find('./ArticleTitle') is not None else ''
            journal = art.find('./Journal') if art is not None else None
            j_iso = (journal.find('./ISOAbbreviation').text or '') if journal is not None and journal.find('./ISOAbbreviation') is not None else ''
            pd = journal.find('./JournalIssue/PubDate') if journal is not None else None
            yr = ''
            if pd is not None:
                ye = pd.find('./Year')
                yr = ye.text if ye is not None and ye.text else ''
                if not yr:
                    ml = pd.find('./MedlineDate')
                    if ml is not None and ml.text:
                        m2 = re.match(r'(\d{4})', ml.text)
                        if m2: yr = m2.group(1)
            doi = ''
            if art is not None:
                de = art.find('.//ELocationID[@EIdType="doi"]')
                doi = de.text if de is not None and de.text else ''
            rows.append({'pmid':pmid,'title':title,'journal':j_iso,'year':yr,'doi':doi})
        time.sleep(0.35)
        print(f'  [{label}] batch {i//BATCH+1}/{(len(pmids)-1)//BATCH+1}: {len(rows)} records', flush=True)
    return rows

# ── 1. Fetch 370 retracted SR/MA ──
print('=== Retracted SR/MA (370) ===')
with open(os.path.join(RAW, 'pmids_retracted_sr_ma.txt')) as f:
    retracted_pmids = [l.strip() for l in f if l.strip()]
print(f'Loaded {len(retracted_pmids)} PMIDs')
r1 = fetch_metadata(retracted_pmids, 'RETR-SRMA')

out1 = os.path.join(OUT, 'retracted_sr_ma_meta.csv')
with open(out1, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['pmid','title','journal','year','doi'])
    w.writeheader(); w.writerows(r1)
print(f'Saved {len(r1)} records to {out1}')

# ── 2. Fetch 41 retracted HCC immunotherapy ──
print('\n=== Retracted HCC Immunotherapy (41) ===')
with open(os.path.join(RAW, 'pmids_retracted_hcc_immunotherapy.txt')) as f:
    hcc_pmids = [l.strip() for l in f if l.strip()]
print(f'Loaded {len(hcc_pmids)} PMIDs')
r2 = fetch_metadata(hcc_pmids, 'HCC-IC')

out2 = os.path.join(OUT, 'retracted_hcc_immunotherapy_meta.csv')
with open(out2, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['pmid','title','journal','year','doi'])
    w.writeheader(); w.writerows(r2)
print(f'Saved {len(r2)} records to {out2}')

print('\n=== Done ===')
