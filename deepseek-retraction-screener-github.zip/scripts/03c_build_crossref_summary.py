"""
Step 3C: Build the final cross-reference table matching retracted articles
to our 9,999 SR/MA corpus, and generate summary statistics.
"""
import csv, os, json
from collections import Counter

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if '__file__' in dir() else os.getcwd()
OUT = os.path.join(BASE, 'data', 'processed')

# 1. Load retraction citation check
with open(os.path.join(OUT, 'retraction_citation_check.csv')) as f:
    citation_data = list(csv.DictReader(f))

# 2. Load our 9,999 SR/MA metadata
with open(os.path.join(OUT, 'metadata_all.csv'), encoding='utf-8') as f:
    corpus = list(csv.DictReader(f))

# 3. Build cross-reference
retracted_by_pmid = {r['pmid']: r for r in citation_data}

# For the paper, we need:
# - How many of the 370 retracted SR/MA are cited (and have non-zero CrossRef count)
# - Which journals contributed most citations to retracted articles
# - Year distribution of citations to retracted articles
# - HCC immunotherapy specific analysis

cited = [r for r in citation_data if int(r.get('cited_by_count',0) or 0) > 0]
total_cites = sum(int(r.get('cited_by_count',0) or 0) for r in citation_data)

print('=' * 60)
print('FINAL CROSS-REFERENCE SUMMARY')
print('=' * 60)

print(f'''
CORPUS STATISTICS
──────────────────
Total SR/MA in corpus:         {len(corpus):>6,}
Retracted SR/MA checked:       {len(citation_data):>6,}
→ With CrossRef citations:     {len(cited):>6,} ({len(cited)*100//len(citation_data)}%)
→ No citations recorded:       {len(citation_data)-len(cited):>6,}
Total citation count (CrossRef): {total_cites:>6,}
''')

# Journal risk profile
journal_cites = Counter()
journal_articles = Counter()
for r in cited:
    journal_cites[r['journal']] += int(r['cited_by_count'])
    journal_articles[r['journal']] += 1

print('JOURNAL RISK PROFILE (citations to retracted articles)')
print(f'{"Journal":40s} {"Articles":>8} {"Cites":>8}')
print('-' * 58)
for j, c in journal_cites.most_common(15):
    a = journal_articles[j]
    print(f'{j[:40]:40s} {a:8d} {c:8d}')

# HCC Immunotherapy focus
print()
print('HCC IMMUNOTHERAPY - CITED RETRACTED ARTICLES')
print('-' * 60)
hcc_cited = [r for r in cited if r.get('source','') == 'hcc' or 
             r['pmid'] in [l.strip() for l in open(os.path.join(BASE, 'data', 'raw', 'pmids_retracted_hcc_immunotherapy.txt'))]]
# Actually filter by checking if pmid is in the HCC file
hcc_pmids = set()
hcc_path = os.path.join(BASE, 'data', 'raw', 'pmids_retracted_hcc_immunotherapy.txt')
if os.path.exists(hcc_path):
    with open(hcc_path) as f:
        hcc_pmids = set(l.strip() for l in f if l.strip())

hcc_retracted_cited = [r for r in cited if r['pmid'] in hcc_pmids]
for r in sorted(hcc_retracted_cited, key=lambda x: -int(x.get('cited_by_count',0))):
    print(f'  cited_by={int(r["cited_by_count"]):4d} | {r["journal"][:25]:25s} | PMID {r["pmid"]}')

# Save summary as JSON
summary = {
    'total_corpus': len(corpus),
    'total_retracted_checked': len(citation_data),
    'with_citations': len(cited),
    'total_citation_count': total_cites,
    'top_journals': [{'journal': j, 'articles': journal_articles[j], 'cites': c} 
                     for j, c in journal_cites.most_common(20)],
}
with open(os.path.join(OUT, 'crossref_summary.json'), 'w') as f:
    json.dump(summary, f, indent=2)
print(f'\nSummary saved to crossref_summary.json')
