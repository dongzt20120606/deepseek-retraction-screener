"""
Step 3B: CrossRef forward citation tracking
For each retracted article, check if any of our 9,999 SR/MAs cite it.
Uses CrossRef REST API.
"""
import urllib.request, json, csv, time, os, re

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if '__file__' in dir() else os.getcwd()
OUT = os.path.join(BASE, 'data', 'processed')

# Load DOIs of retracted articles
def load_dois(path):
    rows = []
    with open(path, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            if r.get('doi'):
                rows.append((r['pmid'], r['doi'], r['title'][:80], r['journal'], r['year']))
    return rows

retracted = load_dois(os.path.join(OUT, 'retracted_sr_ma_meta.csv'))
hcc_retracted = load_dois(os.path.join(OUT, 'retracted_hcc_immunotherapy_meta.csv'))

print(f'Retracted SR/MA with DOIs: {len(retracted)}')
print(f'Retracted HCC immunotherapy with DOIs: {len(hcc_retracted)}')

# CrossRef API: check citations for each DOI
# We'll limit to the top journals (Int Wound J, Tumour Biol, etc.) for a practical first pass
CROSSREF_BASE = 'https://api.crossref.org/works/'

# Also load our 9,999 SR/MA DOIs for cross-referencing
our_pmids = set()
our_dois = {}
with open(os.path.join(OUT, 'metadata_all.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f):
        our_pmids.add(row['pmid'])
        if row.get('doi'):
            our_dois[row['doi'].lower()] = row['pmid']

print(f'Our corpus: {len(our_pmids)} PMIDs, {len(our_dois)} DOIs')

# Forward citation check
def check_citations(doi, label=''):
    """Check CrossRef for articles citing this DOI."""
    url = CROSSREF_BASE + urllib.request.quote(doi, safe='')
    url += '?mailto=dongz@study.cn'  # polite pool
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'RetractionStudy/1.0 (mailto:dongz@study.cn)'})
        resp = urllib.request.urlopen(req, timeout=30)
        data = json.loads(resp.read())
        is_ref_count = data.get('message', {}).get('is-referenced-by-count', 0)
        return is_ref_count, None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return 0, 'not_found'
        return -1, f'HTTP_{e.code}'
    except Exception as e:
        return -1, str(e)

# Check top retracted articles
results = []
all_items = retracted + hcc_retracted
total = len(all_items)
doi_no = 0

for pmid, doi, title, journal, year in all_items:
    if not doi:
        doi_no += 1
        continue
    count, error = check_citations(doi, pmid)
    results.append({
        'pmid': pmid, 'doi': doi, 'title': title, 'journal': journal,
        'year': year, 'cited_by_count': count, 'error': error or ''
    })
    
    status = f'cited_by={count}' if count > 0 else f'cited_by={count}'
    if error: status = f'ERROR: {error}'
    print(f'  [{len(results)}/{total}] PMID {pmid}: {journal[:30]:30s} → {status}', flush=True)
    time.sleep(0.25)  # CrossRef rate limit (50/sec for polite pool, we go slower)

# Save
csv_path = os.path.join(OUT, 'retraction_citation_check.csv')
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['pmid','doi','title','journal','year','cited_by_count','error'])
    w.writeheader(); w.writerows(results)

print(f'\nDONE. Checked {len(results)} DOIs. DOIs missing: {doi_no}')
cited = sum(1 for r in results if r['cited_by_count'] > 0)
total_citations = sum(r['cited_by_count'] for r in results)
print(f'Articles with any citation: {cited}')
print(f'Total citation count: {total_citations}')
