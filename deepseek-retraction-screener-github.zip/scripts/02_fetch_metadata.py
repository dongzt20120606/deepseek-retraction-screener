"""
Phase 1, Task B: Batch download metadata for all PMIDs via NCBI E-utilities efetch
Output: data/processed/metadata_all.csv
Usage: python scripts/02_fetch_metadata.py
"""

import urllib.request
import xml.etree.ElementTree as ET
import csv
import time
import os
import re

RAW = 'data/raw'
OUT = 'data/processed'
os.makedirs(OUT, exist_ok=True)

pmids = [l.strip() for l in open(os.path.join(RAW, 'pmids_cancer_sr_ma.txt')) if l.strip()]
print(f'Loaded {len(pmids)} PMIDs')

all_rows = []
BATCH = 200
TOTAL = len(pmids)

for i in range(0, TOTAL, BATCH):
    batch = pmids[i:i+BATCH]
    start_idx = i
    try:
        url = (
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
            "?db=pubmed&id=" + ",".join(batch) + "&retmode=xml"
        )
        resp = urllib.request.urlopen(
            urllib.request.Request(url, headers={"User-Agent": "Study/1.0"}),
            timeout=60
        )
        root = ET.fromstring(resp.read())

        for article in root.findall('.//PubmedArticle'):
            m = article.find('.//MedlineCitation')
            p = m.find('./PMID') if m is not None else None
            pmid = p.text if p is not None else ''
            art = m.find('./Article') if m is not None else None

            # Title
            title_elem = art.find('./ArticleTitle') if art is not None else None
            title = ''
            if title_elem is not None:
                title = ''.join(title_elem.itertext())
            title = title.replace('\n', ' ').replace('\r', '')

            # Journal
            journal = art.find('./Journal') if art is not None else None
            j_iso_t = ''
            j_full_t = ''
            if journal is not None:
                j_iso = journal.find('./ISOAbbreviation')
                j_title = journal.find('./Title')
                if j_iso is not None and j_iso.text:
                    j_iso_t = j_iso.text
                if j_title is not None and j_title.text:
                    j_full_t = j_title.text

            # Year
            year = ''
            if journal is not None:
                pd = journal.find('./JournalIssue/PubDate')
                if pd is not None:
                    yr_elem = pd.find('./Year')
                    if yr_elem is not None and yr_elem.text:
                        year = yr_elem.text
                    else:
                        ml = pd.find('./MedlineDate')
                        if ml is not None and ml.text:
                            m2 = re.match(r'(\d{4})', ml.text)
                            if m2:
                                year = m2.group(1)

            # DOI
            doi = ''
            if art is not None:
                doi_el = art.find('.//ELocationID[@EIdType="doi"]')
                if doi_el is not None and doi_el.text:
                    doi = doi_el.text

            # Abstract (first 400 chars)
            abs_text = ''
            if art is not None:
                abs_elem = art.find('./Abstract')
                if abs_elem is not None:
                    texts = []
                    for at in abs_elem.iter():
                        if at.tag == 'AbstractText':
                            t = ''.join(at.itertext()).strip()
                            if t:
                                texts.append(t)
                    abs_text = ' '.join(texts)[:400].replace('\n', ' ').replace('\r', '')

            # Pub types
            pts = ''
            if art is not None:
                pt_list = art.find('./PublicationTypeList')
                if pt_list is not None:
                    pts = '; '.join([pt.text for pt in pt_list.findall('./PublicationType') if pt.text])

            # Authors (first 3)
            authors = ''
            if art is not None:
                auth_list = art.find('./AuthorList')
                if auth_list is not None:
                    names = []
                    for a in auth_list.findall('./Author'):
                        last = a.find('./LastName')
                        if last is not None and last.text:
                            names.append(last.text)
                        if len(names) >= 3:
                            break
                    authors = '; '.join(names)
                    if len(auth_list.findall('./Author')) > 3:
                        authors += ' et al.'

            all_rows.append({
                'pmid': pmid,
                'title': title,
                'journal_iso': j_iso_t,
                'journal_full': j_full_t,
                'year': year,
                'authors': authors,
                'doi': doi,
                'abstract': abs_text,
                'pub_types': pts
            })

        pct = (start_idx + len(batch)) * 100 // TOTAL
        bn = start_idx // BATCH + 1
        tn = (TOTAL - 1) // BATCH + 1
        print(f'  [{pct}%] Batch {bn}/{tn}: accumulated {len(all_rows)}', flush=True)
        time.sleep(0.35)

    except Exception as e:
        print(f'  ERROR at batch {start_idx // BATCH + 1}: {e}', flush=True)
        time.sleep(2)
        continue

# Save
csv_path = os.path.join(OUT, 'metadata_all.csv')
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=[
        'pmid', 'title', 'journal_iso', 'journal_full', 'year',
        'authors', 'doi', 'abstract', 'pub_types'
    ])
    w.writeheader()
    w.writerows(all_rows)
print(f'\nDONE. Saved {len(all_rows)} records to {csv_path}')
