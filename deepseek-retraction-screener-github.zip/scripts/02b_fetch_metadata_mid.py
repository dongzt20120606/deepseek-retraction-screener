"""
Phase 1, Task B: Download metadata for PMIDs index 1000-7199
With incremental checkpoint saves for resilience.
"""
import urllib.request, xml.etree.ElementTree as ET, csv, time, os, re

pmids = [l.strip() for l in open('data/raw/pmids_cancer_sr_ma.txt') if l.strip()]
START, END = 1000, 7200
pmids = pmids[START:END]

OUT = 'data/processed'
csv_path = os.path.join(OUT, 'metadata_part1.csv')
BATCH = 200

# Resume if partial file exists
saved = {}
if os.path.exists(csv_path) and os.path.getsize(csv_path) > 0:
    with open(csv_path) as f:
        for row in csv.DictReader(f):
            if row['pmid']:
                saved[row['pmid']] = row
    print(f'Resuming: {len(saved)} PMIDs already saved')

remaining = [p for p in pmids if p not in saved]
print(f'Remaining: {len(remaining)} of {len(pmids)}')

headers = ['pmid','title','journal_iso','journal_full','year','authors','doi','abstract','pub_types']

for i in range(0, len(remaining), BATCH):
    batch = remaining[i:i+BATCH]
    try:
        url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=' + ','.join(batch) + '&retmode=xml'
        resp = urllib.request.urlopen(
            urllib.request.Request(url, headers={'User-Agent': 'Study/1.0'}), timeout=90)
        root = ET.fromstring(resp.read())

        new_rows = []
        for article in root.findall('.//PubmedArticle'):
            m = article.find('.//MedlineCitation')
            pmid = m.find('./PMID').text if m is not None and m.find('./PMID') is not None else ''
            if pmid in saved:
                continue
            art = m.find('./Article') if m is not None else None
            title = ' '.join(art.find('./ArticleTitle').itertext()).replace('\n',' ').replace('\r','') if art is not None and art.find('./ArticleTitle') is not None else ''
            journal = art.find('./Journal') if art is not None else None
            j_iso = (journal.find('./ISOAbbreviation').text or '') if journal is not None and journal.find('./ISOAbbreviation') is not None else ''
            j_full = (journal.find('./Title').text or '') if journal is not None and journal.find('./Title') is not None else ''
            pd = journal.find('./JournalIssue/PubDate') if journal is not None else None
            yr = ''
            if pd is not None:
                ye = pd.find('./Year')
                yr = ye.text if ye is not None and ye.text else ''
                if not yr:
                    ml = pd.find('./MedlineDate')
                    if ml is not None and ml.text:
                        m2 = re.match(r'(\d{4})', ml.text)
                        if m2: yr = m2.group(1)
            doi = ''
            if art is not None:
                de = art.find('.//ELocationID[@EIdType="doi"]')
                doi = de.text if de is not None and de.text else ''
            abs_t = ''
            if art is not None and art.find('./Abstract') is not None:
                ts = [''.join(at.itertext()).strip() for at in art.find('./Abstract').iter() if at.tag == 'AbstractText']
                abs_t = ' '.join(ts)[:400].replace('\n',' ').replace('\r','')
            pts = ''
            if art is not None and art.find('./PublicationTypeList') is not None:
                pts = '; '.join([pt.text for pt in art.find('./PublicationTypeList').findall('./PublicationType') if pt.text])
            auth = ''
            if art is not None and art.find('./AuthorList') is not None:
                al = art.find('./AuthorList')
                names = [a.find('./LastName').text for a in al.findall('./Author') if a.find('./LastName') is not None and a.find('./LastName').text][:3]
                auth = '; '.join(names)
                if len(al.findall('./Author')) > 3: auth += ' et al.'
            new_rows.append({'pmid':pmid,'title':title,'journal_iso':j_iso,'journal_full':j_full,'year':yr,'authors':auth,'doi':doi,'abstract':abs_t,'pub_types':pts})

        if new_rows:
            write_header = (os.path.getsize(csv_path) == 0) if os.path.exists(csv_path) else True
            with open(csv_path, 'a', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=headers)
                if write_header: w.writeheader()
                w.writerows(new_rows)
            for r in new_rows: saved[r['pmid']] = True

        total_saved = (len(pmids) - len(remaining)) + i + len(batch)
        print(f'  [{total_saved*100//len(pmids)}%] +{len(new_rows)} = {len(saved)} total', flush=True)
        time.sleep(0.35)
    except Exception as e:
        print(f'  WARN: {e}', flush=True)
        time.sleep(3)

print(f'Done. {len(saved)} records in {csv_path}')
