"""
Generate a checklist CSV for the user to manually verify 73 items in PubMed.
"""
import csv

with open('deepseek-retraction-screener/output/uncertain_101_my_annotation.csv', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

uncertain = [r for r in rows if r['my_status'] == 'UNCERTAIN']

outpath = 'deepseek-retraction-screener/output/checklist_73_for_review.csv'
with open(outpath, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['序号', '检索用文本 (复制到PubMed)', '你的判断', '备注'])
    w.writerow(['', '', '填 CLEAN 或 RETRACTED', '可选'])
    w.writerow([])
    for i, r in enumerate(uncertain):
        w.writerow([i+1, r['citation'].strip(), '', ''])

print(f'Done: {outpath}')
print(f'Items: {len(uncertain)}')
print()
print('How to use:')
print('1. Open in Excel')
print('2. Copy column B text -> paste in PubMed search box')
print('3. Check if result shows "Retracted Publication" tag')
print('4. Fill column C: CLEAN or RETRACTED')
print('5. Save and send back to me')
