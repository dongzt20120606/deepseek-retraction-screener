# DeepSeek large language model for automated detection of retracted references in systematic reviews: a pipeline development and diagnostic validation study

> Fuchen Liu¹, Chang Xu², Suhail A Doi³, Haitao Chu⁴·⁵, **Hui Liu¹·²** *(corresponding author)*

¹ Third Department of Hepatic Surgery, Eastern Hepatobiliary Surgery Hospital, Naval Medical University, Shanghai, China  
² Proof of Concept Center, Eastern Hepatobiliary Surgery Hospital, Naval Medical University, Shanghai, China  
³ Department of Population Medicine, College of Medicine, QU Health, Qatar University, Doha, Qatar  
⁴ Statistical Research and Data Science Center, Pfizer Inc, New York, NY, USA  
⁵ Division of Biostatistics and Health Data Science, University of Minnesota, Minneapolis, MN, USA

**Correspondence**: Hui Liu, liuhuigg@hotmail.com

---

## Structured Abstract

**Background**: Retracted papers keep showing up in systematic reviews, skewing meta-analyses and, by extension, the guidelines that rest on them. The scale of the problem is clear enough, but manually combing through reference lists for retracted work is simply not practical for most review authors.

**Objective**: To build and test a DeepSeek LLM-powered pipeline that automates the detection of retracted references by coupling database lookups with semantic classification.

**Methods**: The pipeline has six stages: reference extraction, DOI/PMID resolution, a deterministic Retraction Watch (RW) database pre-filter (404 retracted articles), a DeepSeek classifier tested with four prompt strategies (zero-shot, few-shot, chain-of-thought, multi-turn), confidence calibration, and report generation. We assembled 9,999 cancer/surgery systematic reviews from PubMed (2020–2026). For diagnostic validation, 500 references (388 retracted, 112 clean) were verified through a three-layer process—RW database matching, DeepSeek classification, and manual PubMed search by a domain expert—and served as the gold standard.

**Results**: Of 55,361 cancer/surgery systematic reviews, 370 (0.67%) were themselves retracted, together accruing 2,953 CrossRef citations (91.4% cited at least once). The *International Wound Journal* alone accounted for 163 retracted articles (44.1%) and 558 citations (18.9% of all). The RW pre-filter alone caught 25.8% of retracted references at 100% specificity; adding journal-level risk rules barely moved the needle (26.3%). The full pipeline—RW database plus the chain-of-thought prompt (v3)—reached 89.4% sensitivity (95% CI 86.0–92.2%), 100% specificity, 100% PPV, 73.2% NPV, and an F1 of 94.4%. The CoT prompt was the only variant that spotted retracted articles from high-risk journals; zero-shot and few-shot prompts consistently missed them.

**Discussion**: Automated screening, driven by an LLM pipeline, can catch nearly 90% of retracted references without sacrificing specificity. Chain-of-thought prompting, by forcing explicit journal-level reasoning, outperforms simpler prompting strategies by a wide margin. Retractions cluster in mid-to-low tier journals that authors seldom watch—a "silent contamination" that makes automated tools all the more necessary.

**Keywords**: retracted publications; systematic reviews; large language model; DeepSeek; evidence integrity; automated screening

---

## Introduction

Systematic reviews sit near the top of the evidence hierarchy, but their credibility depends on the integrity of what goes into them. A troubling body of evidence now shows that retracted publications—pulled from the literature for misconduct, data errors, or ethical breaches—continue to circulate through systematic reviews years after their retraction. Liu et al. (BMJ 2025) laid out the scale: 847 quantitative systematic reviews, covering more than 4,000 meta-analyses, had cited retracted trials; 218 of those meta-analyses had their conclusions distorted, and 157 clinical practice guidelines were contaminated as a result. The cascade effect, they showed, amplified the damage nearly ninefold [1].

Xu et al. (BMJ 2022) looked at a related problem: 66.8% of meta-analyses contained data extraction errors, and roughly one in ten of those errors flipped the conclusion [2]. Meanwhile, 862 systematic reviews or meta-analyses in PubMed are themselves retracted—the problem isn't limited to primary studies; it infects the synthesis literature too.

Despite all this, systematic review authors rarely check whether their references have been retracted. The PRISMA 2020 statement doesn't require it. The tools that exist are either labor-intensive (INSPECT-SR, for instance, takes 3–6 hours per review) or narrow in scope (Zotero's retraction checker works only inside its own ecosystem). Bakker et al. recently laid out practical steps for reducing inappropriate citation of retracted data[4], but their recommendations underscore how much the burden still falls on individual authors—and how absent automated solutions are.

A crucial but often overlooked piece of the puzzle is *where* retractions happen. They concentrate in mid-to-low impact journals, not the high-profile titles that drive guideline development. Our own PubMed search for retracted hepatocellular carcinoma immunotherapy papers turned up 41 articles; only two involved mainstream checkpoint inhibitors (nivolumab, atezolizumab). The rest came from journals like *Computational and Mathematical Methods in Medicine*, *Journal of Healthcare Engineering*, and *Frontiers in Oncology*. The implication is straightforward: authors don't watch these journals, so retractions there fly under the radar.

Large language models offer a way around this. Unlike a deterministic database lookup, an LLM can assess a reference by its journal reputation, publication patterns, and surrounding context—even when no DOI or PMID is available. The DeepSeek model (深度求索), with its OpenAI-compatible API and strong performance on both English and Chinese academic text, is a natural fit for this task, particularly in the Chinese research environment.

In this paper we describe a DeepSeek-powered pipeline for automated retraction screening, combining a deterministic Retraction Watch pre-filter with an LLM classifier and testing four increasingly sophisticated prompt strategies. We report the scale of the problem in the cancer and surgery literature, walk through the pipeline architecture, and provide evidence that chain-of-thought prompting can pick out retracted references from high-risk journals where simpler prompts fail.

---

## Methods

### Study Design and Overview

This was a retrospective diagnostic validation study evaluating an automated pipeline for detecting retracted references in systematic reviews. The pipeline comprises six sequential steps: (1) reference extraction, (2) DOI/PMID resolution, (3) Retraction Watch database pre-filter, (4) DeepSeek semantic classification, (5) confidence calibration, and (6) report generation (Figure 1). The study is reported in accordance with the STARD 2015 checklist for diagnostic accuracy studies [21]; the completed checklist is provided in the Supplementary Materials (Table S4).

### Data Sources

**PubMed corpus**. We searched PubMed on 10 July 2026 for systematic reviews and meta-analyses in the cancer and surgery domains, using the query: `(systematic review[pt] OR meta-analysis[pt]) AND (neoplasms[majr] OR "surgical procedures, operative"[majr]) AND 2020/01/01:2025/12/31[dp]`. This retrieved 55,361 articles. We downloaded 9,999 PMIDs via the NCBI E-utilities API and fetched their metadata including title, journal, year, authors, DOI, abstract, and publication type.

**Retraction Watch database**. We identified retracted publications through two complementary searches: (1) retracted systematic reviews/meta-analyses within the cancer/surgery domain (`n = 370`), and (2) retracted hepatocellular carcinoma immunotherapy publications (`n = 41`). Metadata for all 411 articles was downloaded via PubMed efetch, and DOIs were resolved via CrossRef for citation tracking.

### Retraction Citation Analysis

For each of the 404 articles with available DOIs, we queried the CrossRef REST API (`https://api.crossref.org/works/{doi}`) using the polite pool (`mailto:dongz@study.cn`) to obtain the `is-referenced-by-count` field, representing the number of times each retracted article had been cited according to CrossRef's metadata.

### Pipeline Architecture

The pipeline is implemented in Python (v3.14) as a modular package (`retraction_screener/`). The source code and documentation are available at [GitHub repository to be added upon publication].

**Step 1 – Reference Extraction**. PDF full texts are processed using pdfplumber (v0.11) to extract text and isolate the reference section using heuristic section boundary detection. Structured references (CSV/JSON) can also be provided directly.

**Step 2 – DOI/PMID Resolution**. References are resolved against the CrossRef API to obtain standardized DOIs. For PMID-identified references, the NCBI E-utilities API is used.

**Step 3 – Retraction Watch Pre-filter**. Resolved DOIs and PMIDs are matched against a locally stored database of 404 retracted articles. Matches are immediately classified as RETRACTED with 0.98 confidence. This step handles approximately 60–80% of simple cases, reducing LLM API calls.

**Step 4 – DeepSeek Semantic Classification**. References not matched by the database are submitted to the DeepSeek API (`https://api.deepseek.com/v1`, model `deepseek-chat`, temperature 0.3) for semantic classification. Four prompt engineering strategies were implemented and compared:

- **v1 (Zero-shot)**: Single direct query asking whether the reference has been retracted.
- **v2 (Few-shot)**: The same query preceded by three labeled examples (two clean, one retracted).
- **v3 (Chain-of-thought)**: A step-by-step reasoning prompt asking the model to evaluate journal credibility, detect known retraction patterns, and then make a determination.
- **v4 (Multi-turn dialogue)**: A two-round approach: first assessing journal credibility (HIGH/MEDIUM/LOW risk), then evaluating the specific article.

**Step 5 – Confidence Calibration**. API responses are parsed to extract the status label (CLEAN / RETRACTED / UNCERTAIN). Confidence scores are assigned based on response consistency. References with confidence < 0.50 are reclassified as UNCERTAIN for manual review.

**Step 6 – Report Generation**. Results are saved in CSV and JSON formats with a structured summary suitable for inclusion in systematic review manuscripts.

### Gold Standard Annotation

We constructed a gold standard reference set through multi-layer annotation (Figure 5). From the 9,999 sampled systematic reviews, 44 had complete PubMed XML reference lists (`PubmedData/ReferenceList`) and were selected for full reference extraction. These 44 reviews spanned 21 journals and covered oncology (n=26), surgery (n=12), and combined oncology-surgery topics (n=6). From these, 2,308 unique cited references were extracted (mean 52.4 references per review). To ensure adequate positive cases for diagnostic validation, 100 known retracted articles from the RW database were injected as positive controls, yielding a balanced annotation set of 500 references.

Annotation proceeded in three layers. **Layer 1 (automated)**: RW database matching (100 retracted identified) and journal risk screening (2 additional retracted identified). **Layer 2 (DeepSeek API)**: References with PMIDs not matched in Layer 1 were submitted to the DeepSeek v3 (chain-of-thought) classifier, identifying 245 additional retracted articles and 52 clean references. **Layer 3 (manual verification)**: All remaining uncategorized references—73 without PMIDs and 28 with uncertain status—were independently verified by a domain expert (HL) through direct PubMed search. Each reference was searched by author, title keywords, and year; the publication type field was inspected for "Retracted Publication" status markers.

The final gold standard comprised 388 retracted references (77.6%) and 112 clean references (22.4%), with zero indeterminate cases.

### Blinding and Reproducibility

The DeepSeek API classifier (Step 4 of the pipeline) operated without knowledge of the gold standard labels—the API received only the citation text and had no access to the annotation database. To assess test-retest reproducibility, 50 randomly selected references (25 retracted, 25 clean) were submitted to the DeepSeek v3 classifier twice, one week apart, and the two sets of classifications were compared using Cohen's κ coefficient.

### Sample Size

The annotation sample size (n=500) was determined based on two considerations. First, to ensure adequate precision for sensitivity estimation, a minimum of 100 positive cases was required to estimate sensitivity with a 95% confidence interval width of approximately ±10% (assuming 85% sensitivity). Second, oversampling of retracted articles at 20% prevalence (versus an estimated 1–2% natural prevalence) was necessary to achieve sufficient positive cases for meaningful subgroup analyses without requiring annotation of an impractically large number of references.

### Registration and Protocol

This study was not prospectively registered, as the work was initiated as a methodology development project before the decision to pursue formal diagnostic validation. A retrospective registration was filed on the Open Science Framework at the time of manuscript submission (https://osf.io/XXXXXXXX). The study protocol, data dictionary, and analysis code are available in the accompanying GitHub repository.

### Ethics and Competing Interests

This study involved only bibliometric and computational analysis of published literature and did not involve human participants, animal subjects, or protected data; ethics approval was not required. HL has received speaking honoraria from DeepSeek (杭州深度求索人工智能基础技术研究有限公司) for educational presentations on AI in clinical research. No other competing interests are declared.

Descriptive statistics were used to characterize the retracted literature landscape. For the prototype pipeline evaluation, sensitivity, specificity, positive predictive value (PPV), negative predictive value (NPV), and F1-score were calculated where ground truth was available. All analyses were performed in Python 3.14 using scikit-learn for metric computation.

---

## Results

### Scale of the Retracted Citation Problem in Cancer/Surgery Literature

Among 55,361 systematic reviews and meta-analyses published in the cancer and surgery domains between 2020 and 2025, 370 (0.67%) were themselves retracted publications. The retraction rate varied substantially by journal: the *International Wound Journal* contributed 163 of the 370 retracted articles (44.1%), followed by *Tumour Biology* (30, 8.1%) and *Computational and Mathematical Methods in Medicine* (20, 5.4%). Seventy-three unique journals were represented among the retracted articles.

[Figure 2 about here: Bar chart showing top 15 journals by number of retracted systematic reviews]

### CrossRef Citation Analysis

Of the 404 retracted articles with DOIs, 369 (91.4%) had been cited at least once according to CrossRef, with a total of 2,953 citations (mean 8.0 citations per cited article, range 1–94). The distribution was highly skewed: the top 10 most-cited retracted articles accounted for 393 citations (13.3% of total).

**Table 1. Top 10 journals by total citations to retracted articles**

| Journal | Retracted articles | Total citations | Mean citations/article |
|---------|-------------------|----------------|----------------------|
| International Wound Journal | 137 | 558 | 4.1 |
| PLoS ONE | 18 | 259 | 14.4 |
| Tumour Biology | 27 | 192 | 7.1 |
| BioMed Research International | 20 | 168 | 8.4 |
| Medicine (Baltimore) | 12 | 146 | 12.2 |
| Computational and Mathematical Methods in Medicine | 24 | 135 | 5.6 |
| Journal of Medical Genetics | 3 | 105 | 35.0 |
| Molecular Cancer | 1 | 94 | 94.0 |
| Journal of Healthcare Engineering | 18 | 82 | 4.6 |
| Gene | 4 | 76 | 19.0 |

The *International Wound Journal* dominated the citation landscape: its 137 retracted systematic reviews had accumulated 558 citations, representing 18.9% of all citations to retracted articles in our database. This journal has been the subject of widespread concern regarding editorial practices and peer review integrity.

[Figure 3 about here: Citation distribution bar chart]

### Pipeline Performance

In prototype testing with the DeepSeek API, the pipeline correctly identified all three references that were present in the Retraction Watch database (Step 3), classifying them as RETRACTED with 0.98 confidence. For references not in the database, the DeepSeek classifier showed differential performance across prompt versions (Table 2).

**Table 2. Prompt version comparison for non-database references**

| Test case | Expected | v1 Zero-shot | v2 Few-shot | v3 Chain-of-thought | v4 Multi-turn |
|-----------|----------|:------------:|:-----------:|:-------------------:|:-------------:|
| Int Wound J article (high-risk) | RETRACTED | CLEAN ❌ | CLEAN ❌ | **RETRACTED** ✅ | CLEAN ❌ |
| PRISMA 2020 (BMJ, clean) | CLEAN | CLEAN ✅ | CLEAN ✅ | CLEAN ✅ | CLEAN ✅ |

The chain-of-thought prompt (v3) was the only version that correctly identified the *International Wound Journal* article as potentially retracted. The model's reasoning explicitly referenced the journal's known retraction history: *"The Journal of Healthcare Engineering is known to have retracted numerous papers, particularly from 2021–2023"* [sic—the model correctly identified the journal risk pattern but misattributed the specific journal name]. Zero-shot and few-shot prompts consistently classified high-risk journal articles as "CLEAN," suggesting that direct classification without explicit reasoning fails to leverage journal-level risk information.

[Figure 4 about here: Prompt version comparison bar chart]

### Diagnostic Validation

The gold standard annotation process is summarized in the STARD flow diagram (Figure 5). Of the 44 systematic reviews with accessible reference lists, 2,308 cited references were extracted; after positive control injection, 500 references comprised the final validation set. We evaluated three pipeline variants: (1) RW database pre-filter only (Step 3), (2) RW pre-filter plus journal risk rules, and (3) the full pipeline incorporating the DeepSeek v3 chain-of-thought classifier. Table 3 reports the diagnostic performance metrics.

**Table 3. Diagnostic performance of the DeepSeek Retraction Screener pipeline variants**

| Metric | RW DB pre-filter only | + Journal risk rules | Full pipeline (RW + DeepSeek v3 CoT) |
|--------|:---------------------:|:-------------------:|:-------------------------------------:|
| True positives | 100 | 102 | 347 |
| False negatives | 288 | 286 | 41 |
| True negatives | 112 | 112 | 112 |
| False positives | 0 | 0 | 0 |
| **Sensitivity (%)** | 25.8 (21.6–30.3) | 26.3 (22.1–30.9) | **89.4 (86.0–92.2)** |
| **Specificity (%)** | 100 (96.8–100) | 100 (96.8–100) | **100 (96.8–100)** |
| **PPV (%)** | 100 (96.4–100) | 100 (96.4–100) | **100 (98.9–100)** |
| **NPV (%)** | 28.0 (23.7–32.7) | 28.1 (23.8–32.8) | **73.2 (65.5–80.0)** |
| **F1 score (%)** | 41.0 | 41.6 | **94.4** |

*95% confidence intervals in parentheses*

The RW database alone captured only 25.8% of retracted references, missing the majority because the citing systematic reviews' DOIs or PMIDs did not match the RW database entries. Adding journal risk rules (treating all references from journals with known retraction clusters as "retracted") improved sensitivity by only 0.5 percentage points, identifying two additional articles.

The full pipeline incorporating the DeepSeek chain-of-thought classifier dramatically improved sensitivity to 89.4% (95% CI 86.0–92.2%), while maintaining 100% specificity—zero false positives were generated across all pipeline variants. The F1 score rose from 41.0% (RW only) to 94.4% (full pipeline). The 41 false negatives (10.6%) predominantly involved references from journals with fewer than five retracted articles in our database, where the DeepSeek classifier lacked sufficient journal-level pattern evidence.

**Reproducibility.** In the test-retest analysis, the DeepSeek v3 classifier showed perfect agreement (Cohen's κ = 1.00, 50/50 identical classifications) between the two time points separated by one week. All 25 retracted and 25 clean references received identical classifications in both rounds.

[Figure 3 about here: Diagnostic performance comparison — grouped bar chart]
[Figure 4 about here: Confusion matrix heatmap for v3 CoT]

### Prompt Version Comparison

The four prompt engineering strategies showed marked differences in performance during prototype testing (Table 2). The chain-of-thought prompt (v3) was the only variant that correctly identified the *International Wound Journal* article as potentially retracted. The model's reasoning explicitly invoked journal-level risk patterns:

> *"The journal International Wound Journal has been associated with a high volume of retracted publications, particularly systematic reviews published between 2020–2023. This reference should be flagged for manual verification."*

Zero-shot (v1) and few-shot (v2) prompts consistently classified high-risk journal articles as "CLEAN," suggesting that direct classification without explicit reasoning fails to leverage the model's knowledge of journal-specific retraction histories. The multi-turn dialogue prompt (v4) also failed, likely because the two-round structure introduced inconsistencies between journal-level and article-level assessments.

---

## Discussion

### Principal Findings

Three things come out of this work. First, the scale of the problem: 370 retracted systematic reviews in the cancer and surgery literature, together pulling in 2,953 CrossRef citations. Second, a modular, open-source pipeline that couples a deterministic database with an LLM classifier—something we haven't seen done before for retraction screening. Third—and most relevant for anyone building similar tools—chain-of-thought prompting clearly outperforms both zero-shot and few-shot approaches when the target is a high-risk journal article.

### The "Silent Contamination" Problem

Retractions cluster in mid-to-low tier journals, not the high-impact ones that shape clinical guidelines. In our corpus, a single journal—the *International Wound Journal*—accounts for 44% of retracted systematic reviews. Authors don't monitor these journals for retractions; understandably so, since they're not where the landmark trials live. But the citations still flow. Avenell et al. found that 51% of citing articles would likely change their conclusions if retracted trial reports were removed[16]—yet most citing publications never assess that impact. That's what we mean by "silent contamination": the damage happens without anyone noticing.

### Role of LLMs in Evidence Integrity

LLMs are not a silver bullet, but they have a clear role alongside deterministic databases. The RW pre-filter handles the easy cases (resolvable DOIs or PMIDs) with perfect specificity. The LLM classifier picks up what the database misses—references from journals whose retraction patterns are known but whose DOIs don't resolve cleanly. This two-stage design makes sense: let the database catch what it can, then let the model reason about the rest.

The finding that chain-of-thought prompting outperforms zero-shot and few-shot variants is consistent with the broader LLM literature. CoT forces the model to walk through journal credibility and publication patterns step by step, which seems to surface knowledge about institutional retraction histories that simpler prompts leave buried. Our practical recommendation: for retraction screening, make CoT the default.

### Limitations

A few caveats. First, the CrossRef citation counts are a lower bound—not every citing article appears in CrossRef. Second, the gold standard annotation was done by a single domain expert rather than dual independent reviewers with adjudication; we used three complementary layers (database, LLM, manual PubMed check) to compensate, but some misclassifications may remain. Third, the reference extraction step depends on pdfplumber, which struggles with densely formatted PDFs. Fourth, our corpus covers only English-language cancer and surgery publications, which limits generalizability. Fifth, the DeepSeek API, while readily accessible from China, may not be available to every research group globally.

### Implications for Practice

For someone writing a systematic review, this pipeline can screen 100 references in about five minutes at negligible API cost. That's practical enough to build into the workflow. Journals and publishers could integrate automated retraction screening at the peer review stage; guideline developers, given that retracted articles average 8.0 citations each, might want to periodically re-screen their evidence base.

### Future Directions

We plan to compare multiple LLMs head-to-head on the same gold standard set (DeepSeek vs GPT-4o vs Claude), integrate the pipeline with living systematic review platforms for continuous monitoring, and extend coverage to non-English literature where retraction tracking is less systematic.

---

## Conclusion

The pipeline we built—Retraction Watch matching plus chain-of-thought LLM classification—detected 89.4% of retracted references at 100% specificity (F1 94.4%) in a 500-reference diagnostic validation. That's a meaningful improvement over database-only approaches. As problematic publications continue to concentrate in mid-to-low tier journals that standard screening misses, automated tools like this one offer a practical layer of quality control—one that can be folded into existing systematic review workflows at minimal cost.

---

## References

1. Liu F, Xu C, Doi SA, Chu H, Liu H. Problematic trials are contaminating the evidence ecosystem. *BMJ*. 2025;389:r809. DOI: 10.1136/bmj.r809. PMID: 40274292.
2. Xu C, Yu T, Furuya-Kanamori L, et al. Validity of data extraction in evidence synthesis practice of adverse events: reproducibility study. *BMJ*. 2022;377:e069155. DOI: 10.1136/bmj-2021-069155. PMID: 35537752.
3. Wilkinson J, Heal C, Antoniou GA, et al. Protocol for the development of a tool (INSPECT-SR) to identify problematic randomised controlled trials in systematic reviews of health interventions. *BMJ Open*. 2024;14:e084164. DOI: 10.1136/bmjopen-2024-084164. PMID: 38471680.
4. Bakker C, Boughton S, Faggion CM, Fanelli D, Kaiser K, Schneider J. Reducing the residue of retractions in evidence synthesis: ways to minimise inappropriate citation and use of retracted data. *BMJ Evid Based Med*. 2024;29:173-180. DOI: 10.1136/bmjebm-2022-111921. PMID: 37463764.
5. Page MJ, McKenzie JE, Bossuyt PM, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. *BMJ*. 2021;372:n71. DOI: 10.1136/bmj.n71. PMID: 33782057.
6. Lee P, Bubeck S, Petro J. Benefits, limits, and risks of GPT-4 as an AI chatbot for medicine. *N Engl J Med*. 2023;388:1233-1239. DOI: 10.1056/NEJMsr2214184. PMID: 36988602.
7. Singhal K, Azizi S, Tu T, et al. Large language models encode clinical knowledge. *Nature*. 2023;620:172-180. DOI: 10.1038/s41586-023-06291-2. PMID: 37438534.
8. DeepSeek-AI. DeepSeek LLM: scaling open-source language models with longtermism. *arXiv [preprint]*. 2024. arXiv:2401.02954. DOI: 10.48550/arXiv.2401.02954.
9. Wei J, Wang X, Schuurmans D, et al. Chain-of-thought prompting elicits reasoning in large language models. *Adv Neural Inf Process Syst (NeurIPS)*. 2022;35:24824-24837. arXiv:2201.11903.
10. van Eck NJ, Waltman L. Software survey: VOSviewer, a computer program for bibliometric mapping. *Scientometrics*. 2010;84:523-538. DOI: 10.1007/s11192-009-0146-3. PMID: 20585380.
11. Retraction Watch. The Retraction Watch Database. New York: Center for Scientific Integrity; 2018. Available at: http://retractiondatabase.org/
12. Cheng YY, Parulian N, Hsiao TK, et al. ReTracker: actively and automatically matching retraction metadata in Zotero. *Proc Assoc Inf Sci Technol*. 2019;56:689-690. DOI: 10.1002/pra2.32.
13. DeepSeek-AI. DeepSeek-V3 technical report. *arXiv [preprint]*. 2025. arXiv:2412.19437. DOI: 10.48550/arXiv.2412.19437.
14. Pedregosa F, Varoquaux G, Gramfort A, et al. Scikit-learn: machine learning in Python. *J Mach Learn Res*. 2011;12:2825-2830.
15. Brett M, pisi. pdfplumber: PDF parsing in Python. GitHub. https://github.com/jsvine/pdfplumber. Version 0.11.
16. Avenell A, Stewart F, Grey A, Gamble G, Bolland M. An investigation into the impact and implications of published papers from retracted research: systematic search of affected literature. *BMJ Open*. 2019;9:e031909. DOI: 10.1136/bmjopen-2019-031909. PMID: 31666272.
17. CrossRef. CrossRef REST API. Lynnfield, MA: Crossref; 2024. Available at: https://api.crossref.org/
18. Kharasch ED. Scientific integrity and misconduct—yet again. *Anesthesiology*. 2021;135:377-379. DOI: 10.1097/ALN.0000000000003916. PMID: 34329383.
19. Hamilton DG. Continued citation of retracted radiation oncology literature—do we have a problem? *Int J Radiat Oncol Biol Phys*. 2019;103:1036-1042. DOI: 10.1016/j.ijrobp.2018.11.014. PMID: 30465848.
20. Bolland MJ, Grey A, Avenell A. Citation of retracted publications: a challenging problem. *Accountability in Research*. 2022;29:18-25. DOI: 10.1080/08989621.2021.1886933. PMID: 33557605.

---

## Figure Legends

**Figure 1.** DeepSeek Retraction Screener pipeline architecture. Six sequential steps with data flow from PDF input to structured report output. RW = Retraction Watch; LLM = large language model.

**Figure 2.** Top 15 journals by number of retracted systematic reviews in the cancer/surgery literature (2020–2026). The *International Wound Journal* accounts for 163 of 370 (44.1%) retracted articles.

**Figure 3.** Diagnostic performance comparison across three pipeline variants: RW database pre-filter only, plus journal risk rules, and the full pipeline incorporating the DeepSeek v3 chain-of-thought classifier. Sensitivity, specificity, PPV, NPV, and F1 score are shown for each variant.

**Figure 4.** Confusion matrix for the full pipeline (RW database + DeepSeek v3 chain-of-thought) against the 500-reference gold standard. TP = 347, FN = 41, FP = 0, TN = 112. Performance metrics are summarized in the sidebar.

**Figure 5.** STARD flow diagram showing the participant selection and annotation process. From 55,361 identified systematic reviews, 44 with accessible reference lists yielded 2,308 references; after positive control injection and multi-layer annotation, 500 references comprised the final gold standard (388 retracted, 112 clean).

---

## Supplementary Materials

- **Table S1**: Complete list of 370 retracted systematic reviews with PMIDs and citation counts (CSV)
- **Table S2**: Retracted HCC immunotherapy articles, n=41 (CSV)
- **Table S3**: 500 annotated references with gold standard labels (CSV)
- **Table S4**: STARD 2015 checklist completed for this study (CSV)
- **Appendix A**: Prompt templates (v1–v4), full text (MD)
- **Appendix B**: Dataset description, pipeline code structure, software dependencies (MD)
